
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;main.c,59 :: 		void interrupt(){
;main.c,60 :: 		if(RCIF_bit) {                                                              // Interrupt occurred on USART receive
	BTFSS      RCIF_bit+0, 5
	GOTO       L_interrupt0
;main.c,61 :: 		if(OERR_bit) {                                                          // Check for overrun error FIRST
	BTFSS      OERR_bit+0, 1
	GOTO       L_interrupt1
;main.c,62 :: 		CREN_bit = 0;                                                       // Reset the receiver logic
	BCF        CREN_bit+0, 4
;main.c,63 :: 		CREN_bit = 1;
	BSF        CREN_bit+0, 4
;main.c,64 :: 		REC = RCREG;                                                        // Clear the FIFO
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,65 :: 		return;                                                             // Exit interrupt handler
	RETURN
;main.c,66 :: 		}
L_interrupt1:
;main.c,68 :: 		if(FERR_bit) {                                                          // Check for framing error
	BTFSS      FERR_bit+0, 2
	GOTO       L_interrupt2
;main.c,69 :: 		REC = RCREG;                                                        // Discard the corrupted byte
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,70 :: 		return;
	RETURN
;main.c,71 :: 		}
L_interrupt2:
;main.c,73 :: 		REC = RCREG;                                                            // Read the data (clears RCIF_bit when finish)
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,75 :: 		if((REC >= '0' && REC <= '9')) {                                        // ONLY store characters that are numbers.
	MOVLW      48
	SUBWF      _REC+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt5
	MOVF       _REC+0, 0
	SUBLW      57
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt5
L__interrupt63:
;main.c,76 :: 		if(index < BUFFER_SIZE - 1) {
	MOVLW      3
	SUBWF      _index+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_interrupt6
;main.c,77 :: 		buffer[index++] = REC;                                             // Store received character
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	MOVF       _REC+0, 0
	MOVWF      INDF+0
	INCF       _index+0, 1
;main.c,78 :: 		buffer[index] = '\0';                                              // Null-terminate the string
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	CLRF       INDF+0
;main.c,79 :: 		}
L_interrupt6:
;main.c,80 :: 		}
L_interrupt5:
;main.c,82 :: 		if(index == 3){                                                         // Full string received (without null terminator)
	MOVF       _index+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt7
;main.c,83 :: 		if(strcmp(buffer, "300") == 0){                                     // "RUN" command received "300"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr1_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt68
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt68:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt8
;main.c,84 :: 		POWER = 1;                                                       // Run indicator = ON
	BSF        RB5_bit+0, 5
;main.c,85 :: 		CCP1CON = 0x0C;                                                  // Set output, restore the PWM (if disabled)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,86 :: 		}
	GOTO       L_interrupt9
L_interrupt8:
;main.c,88 :: 		else if(strcmp(buffer, "400") == 0){                                // "STOP" command received "400"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr2_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt69
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt69:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt10
;main.c,89 :: 		POWER = 0;                                                       // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,90 :: 		CCP1CON = 0x00;                                                  // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,91 :: 		PWM_OUT = 0;                                                     // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,92 :: 		}
	GOTO       L_interrupt11
L_interrupt10:
;main.c,94 :: 		else if(strcmp(buffer, "500") == 0){                                // "EMERGENCY STOP" command received "500"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr3_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt70
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt70:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt12
;main.c,95 :: 		emergencyState = 1;                                              // Set emergency flag
	MOVLW      1
	MOVWF      _emergencyState+0
;main.c,96 :: 		POWER = 0;                                                       // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,97 :: 		CCP1CON = 0x00;                                                  // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,98 :: 		PWM_OUT = 0;                                                     // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,99 :: 		}
	GOTO       L_interrupt13
L_interrupt12:
;main.c,101 :: 		else if(strcmp(buffer, "600") == 0){                                // "ACK" command received "600"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr4_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt71
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt71:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt14
;main.c,102 :: 		if(sensorError) sensorError = 0;
	MOVF       _sensorError+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_interrupt15
	CLRF       _sensorError+0
	GOTO       L_interrupt16
L_interrupt15:
;main.c,104 :: 		else asm goto 0x0000;
	GOTO       0
L_interrupt16:
;main.c,105 :: 		}
	GOTO       L_interrupt17
L_interrupt14:
;main.c,107 :: 		else strcpy(pwmBuffer, buffer);                                     // 0-100 = update pwmBuffer
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_strcpy_to+0
	MOVLW      _buffer+0
	MOVWF      FARG_strcpy_from+0
	CALL       _strcpy+0
L_interrupt17:
L_interrupt13:
L_interrupt11:
L_interrupt9:
;main.c,109 :: 		uartDataReady = 1;                                                   // Set flag to indicate data received
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,110 :: 		index = 0;                                                           // Reset buffer index for next string
	CLRF       _index+0
;main.c,111 :: 		}
L_interrupt7:
;main.c,112 :: 		}
L_interrupt0:
;main.c,114 :: 		if(PIR1.TMR1IF){                                                            // Interrupt after 256us (sensor time out)
	BTFSS      PIR1+0, 0
	GOTO       L_interrupt18
;main.c,115 :: 		PIR1.TMR1IF  = 0;                                                        // Clear the interrupt flag
	BCF        PIR1+0, 0
;main.c,116 :: 		TOUT = 1;                                                                // Set the time out flag
	MOVLW      1
	MOVWF      _TOUT+0
;main.c,117 :: 		T1CON.TMR1ON = 0;                                                        // Stop TMR1
	BCF        T1CON+0, 0
;main.c,118 :: 		SENSOR_DATA  = 1;                                                        // Set pin17 to HIGH
	BSF        RA0_bit+0, 0
;main.c,119 :: 		}
L_interrupt18:
;main.c,120 :: 		}
L__interrupt67:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

;main.c,123 :: 		void main() {
;main.c,125 :: 		CMCON       = 0x07;               // disable comparators
	MOVLW      7
	MOVWF      CMCON+0
;main.c,126 :: 		OPTION_REG  = 0x86;               // RBPU = 1 (PortB pull ups disabled) | PSA = 0 (Prescaler assign. Timer0| PS<2:0> = 110 (Prescaler 1:128)
	MOVLW      134
	MOVWF      OPTION_REG+0
;main.c,127 :: 		GIE_bit     = 0x01;               // bit 7 of INTCON register (Global Interrupt Enable bit)
	BSF        GIE_bit+0, 7
;main.c,128 :: 		PEIE_bit    = 0x01;               // bit 6 of INTCON register (Peripheral Interrupt Enable bit)
	BSF        PEIE_bit+0, 6
;main.c,130 :: 		PIE1.TMR1IE = 0x01;               // enable Timer1 interrupt
	BSF        PIE1+0, 0
;main.c,132 :: 		PR2         = 0xFF;               // starts the TMR2 overflow register at maximum count: 255
	MOVLW      255
	MOVWF      PR2+0
;main.c,133 :: 		T2CON       = 0x06;               // enable TMR2 and prescaler as 1:16
	MOVLW      6
	MOVWF      T2CON+0
;main.c,134 :: 		CCP1CON     = 0x0C;               // enable PWM  mode(12)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,135 :: 		CCPR1L      = 0x00;               // start the PWM in 0%
	CLRF       CCPR1L+0
;main.c,137 :: 		delay_ms(1000);                   // delay before start the USART
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main19:
	DECFSZ     R13+0, 1
	GOTO       L_main19
	DECFSZ     R12+0, 1
	GOTO       L_main19
	DECFSZ     R11+0, 1
	GOTO       L_main19
	NOP
	NOP
;main.c,138 :: 		RCIF_bit    = 0x00;               // clear the USART interruption flag (located at PIR1 register)
	BCF        RCIF_bit+0, 5
;main.c,139 :: 		RCIE_bit    = 0x01;               // enable UART interruption for data reception (located at PIE1 register)
	BSF        RCIE_bit+0, 5
;main.c,140 :: 		SPBRG       = 0x19;               // set USART (8 bits, no parity, 1 stop bit, 9600, asynchronous)
	MOVLW      25
	MOVWF      SPBRG+0
;main.c,141 :: 		TXEN_bit    = 0x01;               // enable transmission (TXSTA register)
	BSF        TXEN_bit+0, 5
;main.c,142 :: 		BRGH_bit    = 0x01;               // baudrate at high speed (TXSTA register)
	BSF        BRGH_bit+0, 2
;main.c,143 :: 		SYNC_bit    = 0x00;               // asynchronous mode (TXSTA register)
	BCF        SYNC_bit+0, 4
;main.c,144 :: 		SPEN_bit    = 0x01;               // enable serial port (RCSTA register)
	BSF        SPEN_bit+0, 7
;main.c,145 :: 		CREN_bit    = 0x01;               // enable continuous reception (RCSTA register)
	BSF        CREN_bit+0, 4
;main.c,147 :: 		TRISA       = 0x01;               // RA0 = input
	MOVLW      1
	MOVWF      TRISA+0
;main.c,148 :: 		PORTA       = 0x01;               // RA0 start in HIGH, the rest in LOW
	MOVLW      1
	MOVWF      PORTA+0
;main.c,149 :: 		TRISB       = 0x02;               // RB1 (RX) as input, the rest as output
	MOVLW      2
	MOVWF      TRISB+0
;main.c,150 :: 		PORTB       = 0x02;               // RB1 starts in HIGH, the rest in LOW
	MOVLW      2
	MOVWF      PORTB+0
;main.c,152 :: 		TXREG = 'r'; cleanBuffer(); TXREG = 'e'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,153 :: 		TXREG = 's'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      115
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,154 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,155 :: 		TXREG = '1'; cleanBuffer(); // Set res to 1 (reset)
	MOVLW      49
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,156 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,159 :: 		while(1){
L_main20:
;main.c,160 :: 		if(!emergencyState){
	MOVF       _emergencyState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main22
;main.c,162 :: 		if(uartDataReady){
	MOVF       _uartDataReady+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main23
;main.c,163 :: 		PWM_VALUE = atoi(pwmBuffer);                                      // Update PWM_VALUE with the received string conv to int
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_atoi_s+0
	CALL       _atoi+0
	MOVF       R0+0, 0
	MOVWF      _PWM_VALUE+0
;main.c,164 :: 		uartDataReady = 0;
	CLRF       _uartDataReady+0
;main.c,165 :: 		PWM();
	CALL       _PWM+0
;main.c,166 :: 		}
L_main23:
;main.c,167 :: 		sensorTick++;
	INCF       _sensorTick+0, 1
	BTFSC      STATUS+0, 2
	INCF       _sensorTick+1, 1
;main.c,168 :: 		if(sensorTick > WAIT_TIME) {                                         // minimal time between DHT11 reading = 1s
	MOVF       _sensorTick+1, 0
	SUBLW      4
	BTFSS      STATUS+0, 2
	GOTO       L__main72
	MOVF       _sensorTick+0, 0
	SUBLW      176
L__main72:
	BTFSC      STATUS+0, 0
	GOTO       L_main24
;main.c,169 :: 		StartSignal();
	CALL       _StartSignal+0
;main.c,170 :: 		sensor();
	CALL       _sensor+0
;main.c,171 :: 		sensorTick = 0;
	CLRF       _sensorTick+0
	CLRF       _sensorTick+1
;main.c,172 :: 		}
L_main24:
;main.c,173 :: 		Delay_ms(1);
	MOVLW      2
	MOVWF      R12+0
	MOVLW      75
	MOVWF      R13+0
L_main25:
	DECFSZ     R13+0, 1
	GOTO       L_main25
	DECFSZ     R12+0, 1
	GOTO       L_main25
;main.c,174 :: 		}
	GOTO       L_main26
L_main22:
;main.c,177 :: 		POWER = 0;                                                           // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,178 :: 		CCP1CON = 0x00;                                                      // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,179 :: 		PWM_OUT = 0;                                                         // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,180 :: 		}
L_main26:
;main.c,181 :: 		}
	GOTO       L_main20
;main.c,182 :: 		}
	GOTO       $+0
; end of _main

_PWM:

;main.c,186 :: 		void PWM() {
;main.c,187 :: 		CCPR1L = PWM_VALUE;                                                            // the PWM output is updated
	MOVF       _PWM_VALUE+0, 0
	MOVWF      CCPR1L+0
;main.c,188 :: 		TEMP[0]= ((int)(PWM_VALUE/2.53)/100%10) + 48;                                  // Send variable data to IHM Nextion. 2.53 is only to convert into percentage at slider.
	MOVF       _PWM_VALUE+0, 0
	MOVWF      R0+0
	CALL       _Byte2Double+0
	MOVLW      133
	MOVWF      R4+0
	MOVLW      235
	MOVWF      R4+1
	MOVLW      33
	MOVWF      R4+2
	MOVLW      128
	MOVWF      R4+3
	CALL       _Div_32x32_FP+0
	CALL       _Double2Int+0
	MOVF       R0+0, 0
	MOVWF      FLOC__PWM+0
	MOVF       R0+1, 0
	MOVWF      FLOC__PWM+1
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,189 :: 		TEMP[1]= ((int)(PWM_VALUE/2.53)/10%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,190 :: 		TEMP[2]= ((int)(PWM_VALUE/2.53)%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,191 :: 		sendPWM();
	CALL       _sendPWM+0
;main.c,193 :: 		}
	RETURN
; end of _PWM

_StartSignal:

;main.c,196 :: 		void StartSignal(){
;main.c,197 :: 		DATA_DIR = 0;
	BCF        TRISA0_bit+0, 0
;main.c,198 :: 		SENSOR_DATA  = 0;
	BCF        RA0_bit+0, 0
;main.c,199 :: 		Delay_ms(18);    // Low for at least 18us     18
	MOVLW      24
	MOVWF      R12+0
	MOVLW      95
	MOVWF      R13+0
L_StartSignal27:
	DECFSZ     R13+0, 1
	GOTO       L_StartSignal27
	DECFSZ     R12+0, 1
	GOTO       L_StartSignal27
;main.c,200 :: 		SENSOR_DATA    = 1;
	BSF        RA0_bit+0, 0
;main.c,202 :: 		T1CON       = 0x00;               // prescaler 1:1, and Timer1 is off initially
	CLRF       T1CON+0
;main.c,203 :: 		PIR1.TMR1IF = 0x00;               // clear TMR INT Flag bit
	BCF        PIR1+0, 0
;main.c,204 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,205 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,206 :: 		T1CON.TMR1ON = 1;
	BSF        T1CON+0, 0
;main.c,208 :: 		if(TMR1L == 22){
	MOVF       TMR1L+0, 0
	XORLW      22
	BTFSS      STATUS+0, 2
	GOTO       L_StartSignal28
;main.c,209 :: 		DATA_DIR = 1;     // Data port is input
	BSF        TRISA0_bit+0, 0
;main.c,210 :: 		T1CON.TMR1ON = 0;
	BCF        T1CON+0, 0
;main.c,211 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,212 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,213 :: 		}
L_StartSignal28:
;main.c,214 :: 		}
	RETURN
; end of _StartSignal

_CheckResponse:

;main.c,217 :: 		unsigned short CheckResponse(){
;main.c,218 :: 		TOUT = 0;
	CLRF       _TOUT+0
;main.c,219 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,220 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,221 :: 		T1CON.TMR1ON = 1;                  // Start TMR1 while waiting for sensor response
	BSF        T1CON+0, 0
;main.c,223 :: 		while(!SENSOR_DATA && !TOUT);       // If there's no response within 256us, the Timer1 overflows
L_CheckResponse29:
	BTFSC      RA0_bit+0, 0
	GOTO       L_CheckResponse30
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse30
L__CheckResponse65:
	GOTO       L_CheckResponse29
L_CheckResponse30:
;main.c,224 :: 		if (TOUT)
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse33
;main.c,225 :: 		return 0;    // and exit
	CLRF       R0+0
	RETURN
L_CheckResponse33:
;main.c,228 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,229 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,230 :: 		while(SENSOR_DATA && !TOUT);
L_CheckResponse35:
	BTFSS      RA0_bit+0, 0
	GOTO       L_CheckResponse36
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse36
L__CheckResponse64:
	GOTO       L_CheckResponse35
L_CheckResponse36:
;main.c,231 :: 		if (TOUT)
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse39
;main.c,232 :: 		return 0;
	CLRF       R0+0
	RETURN
L_CheckResponse39:
;main.c,235 :: 		T1CON.TMR1ON = 0;
	BCF        T1CON+0, 0
;main.c,236 :: 		return 1;
	MOVLW      1
	MOVWF      R0+0
;main.c,239 :: 		}
	RETURN
; end of _CheckResponse

_ReadByte:

;main.c,242 :: 		unsigned short ReadByte(){
;main.c,243 :: 		unsigned short num = 0, i;
	CLRF       ReadByte_num_L0+0
;main.c,244 :: 		DATA_DIR = 1;
	BSF        TRISA0_bit+0, 0
;main.c,246 :: 		for (i=0; i<8; i++){
	CLRF       R2+0
L_ReadByte41:
	MOVLW      8
	SUBWF      R2+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte42
;main.c,247 :: 		while(!SENSOR_DATA);
L_ReadByte44:
	BTFSC      RA0_bit+0, 0
	GOTO       L_ReadByte45
	GOTO       L_ReadByte44
L_ReadByte45:
;main.c,248 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,249 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,250 :: 		T1CON.TMR1ON = 1;  // Start TMR2 from 0 when a low to high data pulse
	BSF        T1CON+0, 0
;main.c,251 :: 		while(SENSOR_DATA);       // is detected, and wait until it falls low again.
L_ReadByte46:
	BTFSS      RA0_bit+0, 0
	GOTO       L_ReadByte47
	GOTO       L_ReadByte46
L_ReadByte47:
;main.c,252 :: 		T1CON.TMR1ON = 0;  // Stop the TMR2 when the data pulse falls low.
	BCF        T1CON+0, 0
;main.c,254 :: 		if(TMR1L > 40)
	MOVF       TMR1L+0, 0
	SUBLW      40
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte48
;main.c,255 :: 		num |= 1<<(7-i);  // If time > 40us, Data is 1
	MOVF       R2+0, 0
	SUBLW      7
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      R1+0
	MOVLW      1
	MOVWF      R0+0
	MOVF       R1+0, 0
L__ReadByte73:
	BTFSC      STATUS+0, 2
	GOTO       L__ReadByte74
	RLF        R0+0, 1
	BCF        R0+0, 0
	ADDLW      255
	GOTO       L__ReadByte73
L__ReadByte74:
	MOVF       R0+0, 0
	IORWF      ReadByte_num_L0+0, 1
L_ReadByte48:
;main.c,246 :: 		for (i=0; i<8; i++){
	INCF       R2+0, 1
;main.c,256 :: 		}
	GOTO       L_ReadByte41
L_ReadByte42:
;main.c,257 :: 		return num;
	MOVF       ReadByte_num_L0+0, 0
	MOVWF      R0+0
;main.c,258 :: 		}
	RETURN
; end of _ReadByte

_sensor:

;main.c,261 :: 		void sensor(){
;main.c,264 :: 		check = CheckResponse();
	CALL       _CheckResponse+0
;main.c,266 :: 		if (!check){
	MOVF       R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensor49
;main.c,268 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,269 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,270 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,271 :: 		TXREG = '1'; cleanBuffer(); // Set er0 to 1 (NOK)
	MOVLW      49
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,272 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,274 :: 		POWER = 0;                                                                  // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,275 :: 		CCP1CON = 0x00;                                                             // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,276 :: 		PWM_OUT = 0;                                                                // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,277 :: 		sensorError = 1;                                                            // Sensor in error state
	MOVLW      1
	MOVWF      _sensorError+0
;main.c,278 :: 		}
	GOTO       L_sensor50
L_sensor49:
;main.c,281 :: 		RH_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte1+0
;main.c,282 :: 		RH_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte2+0
;main.c,283 :: 		T_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte1+0
;main.c,284 :: 		T_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte2+0
;main.c,285 :: 		CheckSum = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _CheckSum+0
;main.c,287 :: 		if (CheckSum == ((RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF) && !sensorError){
	MOVF       _RH_Byte2+0, 0
	ADDWF      _RH_Byte1+0, 0
	MOVWF      R1+0
	CLRF       R1+1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte1+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte2+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVLW      255
	ANDWF      R1+0, 0
	MOVWF      R3+0
	MOVF       R1+1, 0
	MOVWF      R3+1
	MOVLW      0
	ANDWF      R3+1, 1
	MOVLW      0
	XORWF      R3+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__sensor75
	MOVF       R3+0, 0
	XORWF      R0+0, 0
L__sensor75:
	BTFSS      STATUS+0, 2
	GOTO       L_sensor53
	MOVF       _sensorError+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensor53
L__sensor66:
;main.c,289 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,290 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,291 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,292 :: 		TXREG = '0'; cleanBuffer(); // Set er0 to 0 (OK)
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,293 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,296 :: 		if(T_Byte1 > 2) T_Byte1 -= OFFSET_TEMP;   // Subtract 2 degrees
	MOVF       _T_Byte1+0, 0
	SUBLW      2
	BTFSC      STATUS+0, 0
	GOTO       L_sensor54
	MOVLW      2
	SUBWF      _T_Byte1+0, 1
	GOTO       L_sensor55
L_sensor54:
;main.c,297 :: 		else T_Byte1 = 0;              // Prevent negative rollover
	CLRF       _T_Byte1+0
L_sensor55:
;main.c,299 :: 		if(RH_Byte1 > 3) RH_Byte1 -= OFFSET_HUM; // Subtract 3 percent
	MOVF       _RH_Byte1+0, 0
	SUBLW      3
	BTFSC      STATUS+0, 0
	GOTO       L_sensor56
	MOVLW      7
	SUBWF      _RH_Byte1+0, 1
	GOTO       L_sensor57
L_sensor56:
;main.c,300 :: 		else RH_Byte1 = 0;             // Prevent negative rollover
	CLRF       _RH_Byte1+0
L_sensor57:
;main.c,303 :: 		TEMP[0] = RH_Byte1/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,304 :: 		TEMP[1] = RH_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,305 :: 		TEMP[2] = RH_Byte2/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte2+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,306 :: 		sendData('1');
	MOVLW      49
	MOVWF      FARG_sendData_num+0
	CALL       _sendData+0
;main.c,307 :: 		sendGraph('1', RH_Byte1);                                                 // Sends raw value (e.g., 40)
	MOVLW      49
	MOVWF      FARG_sendGraph_id+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      FARG_sendGraph_val+0
	CALL       _sendGraph+0
;main.c,311 :: 		TEMP[0] = T_Byte1/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,312 :: 		TEMP[1] = T_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,313 :: 		TEMP[2] = T_Byte2/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte2+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,314 :: 		sendData('0');
	MOVLW      48
	MOVWF      FARG_sendData_num+0
	CALL       _sendData+0
;main.c,315 :: 		sendGraph('0', T_Byte1);                                                  // Sends raw value (e.g., 21)
	MOVLW      48
	MOVWF      FARG_sendGraph_id+0
	MOVF       _T_Byte1+0, 0
	MOVWF      FARG_sendGraph_val+0
	CALL       _sendGraph+0
;main.c,317 :: 		}
	GOTO       L_sensor58
L_sensor53:
;main.c,321 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,322 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,323 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,324 :: 		TXREG = '0'; cleanBuffer(); // Set er0 to 0 (OK)
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,325 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,326 :: 		}
L_sensor58:
;main.c,328 :: 		}
L_sensor50:
;main.c,330 :: 		}
	RETURN
; end of _sensor

_sendPWM:

;main.c,333 :: 		void sendPWM(){
;main.c,334 :: 		TXREG = 'n';                                                                 //Write in the UART: n0.val=
	MOVLW      110
	MOVWF      TXREG+0
;main.c,335 :: 		cleanBuffer();                                                               //where "n0" is the % field ID in the main page
	CALL       _cleanBuffer+0
;main.c,336 :: 		TXREG = '0';                                                                 //Send char
	MOVLW      48
	MOVWF      TXREG+0
;main.c,337 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,338 :: 		TXREG = '.';
	MOVLW      46
	MOVWF      TXREG+0
;main.c,339 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,340 :: 		TXREG = 'v';
	MOVLW      118
	MOVWF      TXREG+0
;main.c,341 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,342 :: 		TXREG = 'a';
	MOVLW      97
	MOVWF      TXREG+0
;main.c,343 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,344 :: 		TXREG = 'l';
	MOVLW      108
	MOVWF      TXREG+0
;main.c,345 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,346 :: 		TXREG = '=';
	MOVLW      61
	MOVWF      TXREG+0
;main.c,347 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,348 :: 		comData();
	CALL       _comData+0
;main.c,349 :: 		}
	RETURN
; end of _sendPWM

_sendData:

;main.c,352 :: 		void sendData(char num)                                                        //Write in the UART:  x"num".val=
;main.c,354 :: 		TXREG = 'x';                                                                 //Send char
	MOVLW      120
	MOVWF      TXREG+0
;main.c,355 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,356 :: 		TXREG = num;
	MOVF       FARG_sendData_num+0, 0
	MOVWF      TXREG+0
;main.c,357 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,358 :: 		TXREG = '.';
	MOVLW      46
	MOVWF      TXREG+0
;main.c,359 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,360 :: 		TXREG = 'v';
	MOVLW      118
	MOVWF      TXREG+0
;main.c,361 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,362 :: 		TXREG = 'a';
	MOVLW      97
	MOVWF      TXREG+0
;main.c,363 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,364 :: 		TXREG = 'l';
	MOVLW      108
	MOVWF      TXREG+0
;main.c,365 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,366 :: 		TXREG = '=';
	MOVLW      61
	MOVWF      TXREG+0
;main.c,367 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,368 :: 		comData();
	CALL       _comData+0
;main.c,369 :: 		}
	RETURN
; end of _sendData

_sendGraph:

;main.c,372 :: 		void sendGraph(char id, unsigned short val){
;main.c,373 :: 		TEMP[0] = (val / 100) + 48;       // Hundreds
	MOVLW      100
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,374 :: 		TEMP[1] = ((val / 10) % 10) + 48; // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,375 :: 		TEMP[2] = (val % 10) + 48;        // Units
	MOVLW      10
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,378 :: 		TXREG = 'g'; cleanBuffer();
	MOVLW      103
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,379 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,382 :: 		if(id == '0') { TXREG = '0';
	MOVF       FARG_sendGraph_id+0, 0
	XORLW      48
	BTFSS      STATUS+0, 2
	GOTO       L_sendGraph59
	MOVLW      48
	MOVWF      TXREG+0
;main.c,383 :: 		} else { TXREG = '1'; }
	GOTO       L_sendGraph60
L_sendGraph59:
	MOVLW      49
	MOVWF      TXREG+0
L_sendGraph60:
;main.c,384 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,387 :: 		TXREG = '.'; cleanBuffer();
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,388 :: 		TXREG = 'v'; cleanBuffer();
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,389 :: 		TXREG = 'a'; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,390 :: 		TXREG = 'l'; cleanBuffer();
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,391 :: 		TXREG = '='; cleanBuffer();
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,394 :: 		TXREG = TEMP[0]; cleanBuffer();
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,395 :: 		TXREG = TEMP[1]; cleanBuffer();
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,396 :: 		TXREG = TEMP[2]; cleanBuffer();
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,399 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,400 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,401 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,402 :: 		}
	RETURN
; end of _sendGraph

_comData:

;main.c,405 :: 		void comData()                                                                  //common measured data (can be temperature or humidity)
;main.c,407 :: 		TXREG = TEMP[0];                                                             //Send char
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
;main.c,408 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,409 :: 		TXREG = TEMP[1];
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
;main.c,410 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,411 :: 		TXREG = TEMP[2];
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
;main.c,412 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,413 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,414 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,415 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,416 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,417 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,418 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,419 :: 		}
	RETURN
; end of _comData

_cleanBuffer:

;main.c,422 :: 		void cleanBuffer()                                                              //Clean the buffer
;main.c,424 :: 		while(!TRMT_bit);                                                            //while loop until the buffer is not empty
L_cleanBuffer61:
	BTFSC      TRMT_bit+0, 1
	GOTO       L_cleanBuffer62
	GOTO       L_cleanBuffer61
L_cleanBuffer62:
;main.c,425 :: 		}
	RETURN
; end of _cleanBuffer
