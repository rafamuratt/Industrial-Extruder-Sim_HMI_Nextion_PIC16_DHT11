
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;main.c,122 :: 		void interrupt(){
;main.c,123 :: 		if(INTF_bit){
	BTFSS      INTF_bit+0, 1
	GOTO       L_interrupt0
;main.c,125 :: 		hardwareEmgState = 1;
	MOVLW      1
	MOVWF      _hardwareEmgState+0
;main.c,126 :: 		CCP1CON = 0x00;                                                         // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,127 :: 		PWM_OUT = 0;                                                            // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,128 :: 		POWER = 0;                                                              // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,129 :: 		INTF_bit = 0;                                                           // Clear the flag
	BCF        INTF_bit+0, 1
;main.c,130 :: 		}
L_interrupt0:
;main.c,132 :: 		if(!hardwareEmgState){                                                      // hw emergency is released
	MOVF       _hardwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt1
;main.c,133 :: 		if(RCIF_bit){
	BTFSS      RCIF_bit+0, 5
	GOTO       L_interrupt2
;main.c,135 :: 		if(OERR_bit){                                                       // Check for overrun error FIRST
	BTFSS      OERR_bit+0, 1
	GOTO       L_interrupt3
;main.c,136 :: 		CREN_bit = 0;                                                   // Reset the receiver logic
	BCF        CREN_bit+0, 4
;main.c,137 :: 		CREN_bit = 1;
	BSF        CREN_bit+0, 4
;main.c,138 :: 		REC = RCREG;                                                    // Clear the FIFO
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,139 :: 		return;                                                         // Exit interrupt handler
	RETURN
;main.c,140 :: 		}
L_interrupt3:
;main.c,142 :: 		if(FERR_bit){                                                       // Check for framing error
	BTFSS      FERR_bit+0, 2
	GOTO       L_interrupt4
;main.c,143 :: 		REC = RCREG;                                                    // Discard the corrupted byte
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,144 :: 		return;
	RETURN
;main.c,145 :: 		}
L_interrupt4:
;main.c,147 :: 		REC = RCREG;                                                        // Read the data (auto clear the RCIF_bit when finish)
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,149 :: 		if((REC >= '0' && REC <= '9')){                                     // ONLY store characters that are numbers.
	MOVLW      48
	SUBWF      _REC+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt7
	MOVF       _REC+0, 0
	SUBLW      57
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt7
L__interrupt72:
;main.c,150 :: 		if(index < BUFFER_SIZE - 1){
	MOVLW      3
	SUBWF      _index+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_interrupt8
;main.c,151 :: 		buffer[index++] = REC;                                         // Store received character
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	MOVF       _REC+0, 0
	MOVWF      INDF+0
	INCF       _index+0, 1
;main.c,152 :: 		buffer[index] = '\0';                                          // Null-terminate the string
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	CLRF       INDF+0
;main.c,153 :: 		}
L_interrupt8:
;main.c,154 :: 		}
L_interrupt7:
;main.c,156 :: 		if(index == 3){                                                     // Full string received (without null terminator)
	MOVF       _index+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt9
;main.c,157 :: 		if(strcmp(buffer, "300") == 0){                                 // "RUN" command received "300"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr1_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt78
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt78:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt10
;main.c,158 :: 		CCP1CON = 0x0C;                                              // Set output, restore the PWM (if disabled)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,159 :: 		POWER = 1;                                                   // Run indicator = ON
	BSF        RB5_bit+0, 5
;main.c,160 :: 		}
	GOTO       L_interrupt11
L_interrupt10:
;main.c,162 :: 		else if(strcmp(buffer, "400") == 0){                            // "STOP" command received "400"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr2_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt79
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt79:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt12
;main.c,163 :: 		CCP1CON = 0x00;
	CLRF       CCP1CON+0
;main.c,164 :: 		PWM_OUT = 0;
	BCF        RB3_bit+0, 3
;main.c,165 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,166 :: 		}
	GOTO       L_interrupt13
L_interrupt12:
;main.c,168 :: 		else if(strcmp(buffer, "500") == 0){                            // "EMERGENCY STOP" command received "500"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr3_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt80
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt80:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt14
;main.c,169 :: 		softwareEmgState = 1;                                        // Set emergency flag
	MOVLW      1
	MOVWF      _softwareEmgState+0
;main.c,170 :: 		CCP1CON = 0x00;
	CLRF       CCP1CON+0
;main.c,171 :: 		PWM_OUT = 0;
	BCF        RB3_bit+0, 3
;main.c,172 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,173 :: 		}
	GOTO       L_interrupt15
L_interrupt14:
;main.c,175 :: 		else if(strcmp(buffer, "600") == 0){                            // "ACK" command received "600"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr4_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt81
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt81:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt16
;main.c,176 :: 		if(sensorError){
	MOVF       _sensorError+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_interrupt17
;main.c,177 :: 		sensorError = 0;                                            // Clean the flag
	CLRF       _sensorError+0
;main.c,178 :: 		}
	GOTO       L_interrupt18
L_interrupt17:
;main.c,179 :: 		else asm goto 0x0000;                                        // If Emergency ACK, restart uC
	GOTO       0
L_interrupt18:
;main.c,180 :: 		}
	GOTO       L_interrupt19
L_interrupt16:
;main.c,182 :: 		else strcpy(pwmBuffer, buffer);                                 // 0-100 = update pwmBuffer
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_strcpy_to+0
	MOVLW      _buffer+0
	MOVWF      FARG_strcpy_from+0
	CALL       _strcpy+0
L_interrupt19:
L_interrupt15:
L_interrupt13:
L_interrupt11:
;main.c,183 :: 		uartDataReady = 1;                                              // Set flag to indicate data received
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,184 :: 		index = 0;                                                      // Reset buffer index for next string
	CLRF       _index+0
;main.c,185 :: 		}
L_interrupt9:
;main.c,186 :: 		}
L_interrupt2:
;main.c,188 :: 		if(PIR1.TMR1IF){
	BTFSS      PIR1+0, 0
	GOTO       L_interrupt20
;main.c,190 :: 		PIR1.TMR1IF  = 0;                                                    // Clear the interrupt flag
	BCF        PIR1+0, 0
;main.c,191 :: 		TOUT = 1;                                                            // Set the time out flag
	MOVLW      1
	MOVWF      _TOUT+0
;main.c,192 :: 		T1CON.TMR1ON = 0;                                                    // Stop TMR1
	BCF        T1CON+0, 0
;main.c,193 :: 		SENSOR_DATA  = 1;                                                    // Set pin17 to HIGH
	BSF        RA0_bit+0, 0
;main.c,194 :: 		}
L_interrupt20:
;main.c,195 :: 		}
L_interrupt1:
;main.c,196 :: 		}
L__interrupt77:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

;main.c,200 :: 		void main(){
;main.c,201 :: 		CMCON       = 0x07;                                                      // Disable comparators
	MOVLW      7
	MOVWF      CMCON+0
;main.c,202 :: 		OPTION_REG  = 0x80;                                                      // RBPU = 1 (PortB pull ups disabled)| INTEDG = 0 (RB0/INT falling edge)
	MOVLW      128
	MOVWF      OPTION_REG+0
;main.c,203 :: 		INTE_bit    = 0x01;                                                      // Enable external interrup for emergency hardware button on pin6
	BSF        INTE_bit+0, 4
;main.c,204 :: 		GIE_bit     = 0x01;                                                      // Bit 7 of INTCON register (Global Interrupt Enable bit)
	BSF        GIE_bit+0, 7
;main.c,205 :: 		PEIE_bit    = 0x01;                                                      // Bit 6 of INTCON register (Peripheral Interrupt Enable bit)
	BSF        PEIE_bit+0, 6
;main.c,208 :: 		PIE1.TMR1IE = 0x01;                                                      // Enable Timer1 interrupt
	BSF        PIE1+0, 0
;main.c,211 :: 		PR2         = 0xFF;                                                      // Starts the TMR2 overflow register in the maximum count: 255
	MOVLW      255
	MOVWF      PR2+0
;main.c,212 :: 		T2CON       = 0x06;                                                      // Enable TMR2 and prescaler as 1:16 (PWM frequency = 244.14 Hz)
	MOVLW      6
	MOVWF      T2CON+0
;main.c,213 :: 		CCP1CON     = 0x0C;                                                      // Enable PWM
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,214 :: 		CCPR1L      = 0x00;                                                      // Start the PWM in 0%
	CLRF       CCPR1L+0
;main.c,216 :: 		delay_ms(1000);                                                          // Delay before start the USART
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main21:
	DECFSZ     R13+0, 1
	GOTO       L_main21
	DECFSZ     R12+0, 1
	GOTO       L_main21
	DECFSZ     R11+0, 1
	GOTO       L_main21
	NOP
	NOP
;main.c,217 :: 		RCIF_bit    = 0x00;                                                      // Clear the USART interruption flag (located at PIR1 register)
	BCF        RCIF_bit+0, 5
;main.c,218 :: 		RCIE_bit    = 0x01;                                                      // Enable UART interruption for data reception (located at PIE1 register)
	BSF        RCIE_bit+0, 5
;main.c,220 :: 		SPBRG       = 0x19;                                                      // Set USART (8 bits, no parity, 1 stop bit, 9600, asynchronous)
	MOVLW      25
	MOVWF      SPBRG+0
;main.c,221 :: 		TXEN_bit    = 0x01;                                                      // Enable transmission (TXSTA register)
	BSF        TXEN_bit+0, 5
;main.c,222 :: 		BRGH_bit    = 0x01;                                                      // Baudrate at high speed (TXSTA register)
	BSF        BRGH_bit+0, 2
;main.c,223 :: 		SYNC_bit    = 0x00;                                                      // Asynchronous mode (TXSTA register)
	BCF        SYNC_bit+0, 4
;main.c,224 :: 		SPEN_bit    = 0x01;                                                      // Enable serial port (RCSTA register)
	BSF        SPEN_bit+0, 7
;main.c,225 :: 		CREN_bit    = 0x01;                                                      // Enable continuous reception (RCSTA register)
	BSF        CREN_bit+0, 4
;main.c,227 :: 		TRISA       = 0x01;                                                      // RA0 = input
	MOVLW      1
	MOVWF      TRISA+0
;main.c,228 :: 		PORTA       = 0x01;                                                      // RA0 start in HIGH, the rest in LOW
	MOVLW      1
	MOVWF      PORTA+0
;main.c,229 :: 		TRISB       = 0x03;                                                      // RB1 (RX) as input, the rest as output
	MOVLW      3
	MOVWF      TRISB+0
;main.c,230 :: 		PORTB       = 0x03;                                                      // RB1 starts in HIGH, the rest in LOW
	MOVLW      3
	MOVWF      PORTB+0
;main.c,232 :: 		if (EMG == 0) hardwareEmgState = 1;                                      // Only start if the emergency button is released
	BTFSC      RB0_bit+0, 0
	GOTO       L_main22
	MOVLW      1
	MOVWF      _hardwareEmgState+0
	GOTO       L_main23
L_main22:
;main.c,235 :: 		TXREG = 'r'; cleanBuffer();                                          // Send "res.val=1" (flag to indicate the PIC reset to the HMI)
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,236 :: 		TXREG = 'e'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,237 :: 		TXREG = 's'; cleanBuffer();
	MOVLW      115
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,238 :: 		hmi_nameParameter();                                                 // ".val="
	CALL       _hmi_nameParameter+0
;main.c,239 :: 		TXREG = '1'; cleanBuffer();
	MOVLW      49
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,240 :: 		hmi_endCommand();                                                    // "0xFF 0xFF 0xFF" (end of Nextion command)
	CALL       _hmi_endCommand+0
;main.c,241 :: 		}
L_main23:
;main.c,243 :: 		while(1){
L_main24:
;main.c,244 :: 		if(!softwareEmgState && !hardwareEmgState){
	MOVF       _softwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main28
	MOVF       _hardwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main28
L__main73:
;main.c,245 :: 		if(uartDataReady){
	MOVF       _uartDataReady+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main29
;main.c,246 :: 		PWM_VALUE = atoi(pwmBuffer);                                  // Update PWM_VALUE with the received string (converted to int)
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_atoi_s+0
	CALL       _atoi+0
	MOVF       R0+0, 0
	MOVWF      _PWM_VALUE+0
;main.c,247 :: 		uartDataReady = 0;
	CLRF       _uartDataReady+0
;main.c,248 :: 		PWM();
	CALL       _PWM+0
;main.c,249 :: 		}
L_main29:
;main.c,250 :: 		sensorTick++;
	INCF       _sensorTick+0, 1
	BTFSC      STATUS+0, 2
	INCF       _sensorTick+1, 1
;main.c,251 :: 		if(sensorTick > WAIT_TIME){                                      // minimal time between DHT11 reading = 1s
	MOVF       _sensorTick+1, 0
	SUBLW      4
	BTFSS      STATUS+0, 2
	GOTO       L__main82
	MOVF       _sensorTick+0, 0
	SUBLW      176
L__main82:
	BTFSC      STATUS+0, 0
	GOTO       L_main30
;main.c,252 :: 		startSensor();
	CALL       _startSensor+0
;main.c,253 :: 		sensorHandling();
	CALL       _sensorHandling+0
;main.c,254 :: 		sensorTick = 0;
	CLRF       _sensorTick+0
	CLRF       _sensorTick+1
;main.c,255 :: 		}
L_main30:
;main.c,256 :: 		}
	GOTO       L_main31
L_main28:
;main.c,259 :: 		CCP1CON = 0x00;                                                  // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,260 :: 		PWM_OUT = 0;                                                     // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,261 :: 		POWER = 0;                                                       // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,263 :: 		while(1){                                                        // Force emergency release + reset
L_main32:
;main.c,264 :: 		errorState('1','1');                                           // Tell HMI there is emergency error sending: "er1.val=1"
	MOVLW      49
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,265 :: 		delay_ms(500);
	MOVLW      3
	MOVWF      R11+0
	MOVLW      138
	MOVWF      R12+0
	MOVLW      85
	MOVWF      R13+0
L_main34:
	DECFSZ     R13+0, 1
	GOTO       L_main34
	DECFSZ     R12+0, 1
	GOTO       L_main34
	DECFSZ     R11+0, 1
	GOTO       L_main34
	NOP
	NOP
;main.c,266 :: 		}
	GOTO       L_main32
;main.c,267 :: 		}
L_main31:
;main.c,268 :: 		Delay_ms(1);
	MOVLW      2
	MOVWF      R12+0
	MOVLW      75
	MOVWF      R13+0
L_main35:
	DECFSZ     R13+0, 1
	GOTO       L_main35
	DECFSZ     R12+0, 1
	GOTO       L_main35
;main.c,269 :: 		}
	GOTO       L_main24
;main.c,270 :: 		}
	GOTO       $+0
; end of _main

_PWM:

;main.c,275 :: 		void PWM(){
;main.c,276 :: 		CCPR1L = PWM_VALUE;                                                        // The PWM output is updated. "2.53" is to convert one byte into percentage (for PWM slider h0).
	MOVF       _PWM_VALUE+0, 0
	MOVWF      CCPR1L+0
;main.c,277 :: 		TEMP[0]= ((int)(PWM_VALUE/2.53)/100%10) + 48;                              // Hundreds
	MOVF       _PWM_VALUE+0, 0
	MOVWF      R0+0
	CALL       _Byte2Double+0
	MOVLW      133
	MOVWF      R4+0
	MOVLW      235
	MOVWF      R4+1
	MOVLW      33
	MOVWF      R4+2
	MOVLW      128
	MOVWF      R4+3
	CALL       _Div_32x32_FP+0
	CALL       _Double2Int+0
	MOVF       R0+0, 0
	MOVWF      FLOC__PWM+0
	MOVF       R0+1, 0
	MOVWF      FLOC__PWM+1
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,278 :: 		TEMP[1]= ((int)(PWM_VALUE/2.53)/10%10) + 48;                               // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,279 :: 		TEMP[2]= ((int)(PWM_VALUE/2.53)%10) + 48;                                  // Units
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,280 :: 		sendPWM();
	CALL       _sendPWM+0
;main.c,281 :: 		}
	RETURN
; end of _PWM

_startSensor:

;main.c,286 :: 		void startSensor(){
;main.c,287 :: 		DATA_DIR = 0;                                                             // Set TRISA0 as output
	BCF        TRISA0_bit+0, 0
;main.c,289 :: 		SENSOR_DATA = 0;                                                          // Low on pin17 (DHT11)
	BCF        RA0_bit+0, 0
;main.c,290 :: 		Delay_ms(18);                                                             // Keep low least 18us, the sensor detect the MCU "request signal"
	MOVLW      24
	MOVWF      R12+0
	MOVLW      95
	MOVWF      R13+0
L_startSensor36:
	DECFSZ     R13+0, 1
	GOTO       L_startSensor36
	DECFSZ     R12+0, 1
	GOTO       L_startSensor36
;main.c,291 :: 		SENSOR_DATA = 1;                                                          // High
	BSF        RA0_bit+0, 0
;main.c,294 :: 		T1CON = 0x00;                                                             // Prescaler 1:1, and Timer1 is off initially
	CLRF       T1CON+0
;main.c,295 :: 		PIR1.TMR1IF = 0x00;                                                       // Clear TMR INT Flag bit
	BCF        PIR1+0, 0
;main.c,296 :: 		TMR1L = 0x00;                                                             // Set TMR1L = 0
	CLRF       TMR1L+0
;main.c,297 :: 		TMR1H = 0xFF;                                                             // Set TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,298 :: 		T1CON.TMR1ON = 1;                                                         // Start Timer1 to keep the MCU pulse high during ca. 22us
	BSF        T1CON+0, 0
;main.c,300 :: 		if(TMR1L == 22){                                                          // After 22us, reset timers (preparation to receive the sensor "response signal")
	MOVF       TMR1L+0, 0
	XORLW      22
	BTFSS      STATUS+0, 2
	GOTO       L_startSensor37
;main.c,301 :: 		DATA_DIR = 1;                                                          // Set TRISA0 as input
	BSF        TRISA0_bit+0, 0
;main.c,302 :: 		SENSOR_DATA = 0;                                                       // Low on pin17 (DHT11)
	BCF        RA0_bit+0, 0
;main.c,303 :: 		T1CON.TMR1ON = 0;                                                      // Stop Timer1
	BCF        T1CON+0, 0
;main.c,304 :: 		TMR1L = 0x00;                                                          // Reset TMR1L = 0
	CLRF       TMR1L+0
;main.c,305 :: 		TMR1H = 0xFF;                                                          // Reset TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,306 :: 		}
L_startSensor37:
;main.c,307 :: 		}
	RETURN
; end of _startSensor

_sensorHandling:

;main.c,312 :: 		void sensorHandling(){
;main.c,315 :: 		check = sensorAlive();                                                        // When the sensor is OK, check = 1
	CALL       _sensorAlive+0
;main.c,317 :: 		if (!check){
	MOVF       R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensorHandling38
;main.c,318 :: 		errorState('0','1');                                                        // SENSOR TIMEOUT: Tell HMI there is a sensor error sending: "er0.val=1"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,319 :: 		CCP1CON = 0x00;                                                             // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,320 :: 		PWM_OUT = 0;                                                                // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,321 :: 		POWER = 0;                                                                  // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,322 :: 		sensorError = 1;                                                            // Sensor in error state
	MOVLW      1
	MOVWF      _sensorError+0
;main.c,323 :: 		}
	GOTO       L_sensorHandling39
L_sensorHandling38:
;main.c,327 :: 		RH_Byte1 = sensorReadByte();
	CALL       _sensorReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte1+0
;main.c,328 :: 		RH_Byte2 = sensorReadByte();
	CALL       _sensorReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte2+0
;main.c,329 :: 		T_Byte1 = sensorReadByte();
	CALL       _sensorReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte1+0
;main.c,330 :: 		T_Byte2 = sensorReadByte();
	CALL       _sensorReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte2+0
;main.c,331 :: 		CheckSum = sensorReadByte();
	CALL       _sensorReadByte+0
	MOVF       R0+0, 0
	MOVWF      _CheckSum+0
;main.c,334 :: 		if ((CheckSum == (RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF) && !sensorError){ // Force ACK to clear "!errorSensor"
	MOVF       _RH_Byte2+0, 0
	ADDWF      _RH_Byte1+0, 0
	MOVWF      R1+0
	CLRF       R1+1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte1+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte2+0, 0
	ADDWF      R1+0, 0
	MOVWF      R3+0
	MOVF       R1+1, 0
	BTFSC      STATUS+0, 0
	ADDLW      1
	MOVWF      R3+1
	MOVLW      0
	XORWF      R3+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__sensorHandling83
	MOVF       R3+0, 0
	XORWF      R0+0, 0
L__sensorHandling83:
	MOVLW      1
	BTFSS      STATUS+0, 2
	MOVLW      0
	MOVWF      R1+0
	MOVLW      255
	ANDWF      R1+0, 0
	MOVWF      R0+0
	BTFSC      STATUS+0, 2
	GOTO       L_sensorHandling42
	MOVF       _sensorError+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensorHandling42
L__sensorHandling74:
;main.c,335 :: 		errorState('0','0');                                                  // SUCCESS: send to HMI: "er0.val=0"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      48
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,338 :: 		if(T_Byte1 > OFFSET_TEMP) T_Byte1 -= OFFSET_TEMP;                     // Subtract the offset
	MOVF       _T_Byte1+0, 0
	SUBLW      2
	BTFSC      STATUS+0, 0
	GOTO       L_sensorHandling43
	MOVLW      2
	SUBWF      _T_Byte1+0, 1
	GOTO       L_sensorHandling44
L_sensorHandling43:
;main.c,339 :: 		else T_Byte1 = 0;                                                     // Prevent negative rollover
	CLRF       _T_Byte1+0
L_sensorHandling44:
;main.c,341 :: 		if(RH_Byte1 > OFFSET_HUM) RH_Byte1 -= OFFSET_HUM;                     // Subtract the offset
	MOVF       _RH_Byte1+0, 0
	SUBLW      6
	BTFSC      STATUS+0, 0
	GOTO       L_sensorHandling45
	MOVLW      6
	SUBWF      _RH_Byte1+0, 1
	GOTO       L_sensorHandling46
L_sensorHandling45:
;main.c,342 :: 		else RH_Byte1 = 0;                                                    // Prevent negative rollover
	CLRF       _RH_Byte1+0
L_sensorHandling46:
;main.c,345 :: 		TEMP[0] = RH_Byte1/100 + 48;                                          // Hundreds
	MOVLW      100
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,346 :: 		TEMP[1] = ((RH_Byte1/10)%10) + 48;                                    // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,347 :: 		TEMP[2] = RH_Byte1%10 + 48;                                           // Units
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,348 :: 		sendData('1');
	MOVLW      49
	MOVWF      FARG_sendData_val+0
	CALL       _sendData+0
;main.c,349 :: 		sendGraph('1');
	MOVLW      49
	MOVWF      FARG_sendGraph_id+0
	CALL       _sendGraph+0
;main.c,352 :: 		TEMP[0] = T_Byte1/100 + 48;
	MOVLW      100
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,353 :: 		TEMP[1] = ((T_Byte1/10)%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,354 :: 		TEMP[2] = T_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,355 :: 		sendData('0');
	MOVLW      48
	MOVWF      FARG_sendData_val+0
	CALL       _sendData+0
;main.c,356 :: 		sendGraph('0');
	MOVLW      48
	MOVWF      FARG_sendGraph_id+0
	CALL       _sendGraph+0
;main.c,358 :: 		}
	GOTO       L_sensorHandling47
L_sensorHandling42:
;main.c,362 :: 		errorState('0', '1');                                               // Tell HMI there is a sensor error sending: "er0.val=1"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,363 :: 		CCP1CON = 0x00;                                                     // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,364 :: 		PWM_OUT = 0;                                                        // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,365 :: 		POWER = 0;                                                          // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,366 :: 		sensorError = 1;                                                    // Sensor in error state
	MOVLW      1
	MOVWF      _sensorError+0
;main.c,367 :: 		}
L_sensorHandling47:
;main.c,368 :: 		}
L_sensorHandling39:
;main.c,369 :: 		}
	RETURN
; end of _sensorHandling

_sensorAlive:

;main.c,374 :: 		unsigned short sensorAlive(){
;main.c,375 :: 		TOUT = 0;                                                                 // Reset Time Out flag
	CLRF       _TOUT+0
;main.c,376 :: 		T1CON.TMR1ON = 1;                                                         // Start TMR1 (previoulsy reseted in startSensor()
	BSF        T1CON+0, 0
;main.c,378 :: 		while(!SENSOR_DATA && !TOUT);                                             // Wait for the "sensor response" on pin17 (high pulse from sensor, of ca. 80us)
L_sensorAlive48:
	BTFSC      RA0_bit+0, 0
	GOTO       L_sensorAlive49
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensorAlive49
L__sensorAlive76:
	GOTO       L_sensorAlive48
L_sensorAlive49:
;main.c,379 :: 		if(TOUT)                                                                  // If there's no response within 256us, the Timer1 overflows, Time Out
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_sensorAlive52
;main.c,380 :: 		return 0;                                                              // Sensor data is NOK, exit
	CLRF       R0+0
	RETURN
L_sensorAlive52:
;main.c,383 :: 		TMR1L = 0x00;                                                         // Reset TMR1L = 0
	CLRF       TMR1L+0
;main.c,384 :: 		TMR1H = 0xFF;                                                         // Reset TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,386 :: 		while(SENSOR_DATA && !TOUT);                                          // Wait for the "sensor data" on pin17
L_sensorAlive54:
	BTFSS      RA0_bit+0, 0
	GOTO       L_sensorAlive55
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensorAlive55
L__sensorAlive75:
	GOTO       L_sensorAlive54
L_sensorAlive55:
;main.c,387 :: 		if(TOUT)                                                              // If nothing comes within 256us, the Timer1 overflows, Time Out
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_sensorAlive58
;main.c,388 :: 		return 0;                                                          // Sensor data is NOK, exit
	CLRF       R0+0
	RETURN
L_sensorAlive58:
;main.c,391 :: 		T1CON.TMR1ON = 0;                                                    // Stop Timer1
	BCF        T1CON+0, 0
;main.c,392 :: 		return 1;                                                            // Sensor data is OK, return
	MOVLW      1
	MOVWF      R0+0
;main.c,395 :: 		}
	RETURN
; end of _sensorAlive

_sensorReadByte:

;main.c,400 :: 		unsigned short sensorReadByte(){
;main.c,401 :: 		unsigned short num = 0, i;
	CLRF       sensorReadByte_num_L0+0
;main.c,402 :: 		DATA_DIR = 1;                                                                 // Set TRISA0 as input
	BSF        TRISA0_bit+0, 0
;main.c,404 :: 		for (i=0; i<8; i++){
	CLRF       R2+0
L_sensorReadByte60:
	MOVLW      8
	SUBWF      R2+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_sensorReadByte61
;main.c,405 :: 		while(!SENSOR_DATA);                                                     // Wait until the first data trasition (low to high edge) comes
L_sensorReadByte63:
	BTFSC      RA0_bit+0, 0
	GOTO       L_sensorReadByte64
	GOTO       L_sensorReadByte63
L_sensorReadByte64:
;main.c,407 :: 		TMR1L = 0x00;                                                            // Reset timers
	CLRF       TMR1L+0
;main.c,408 :: 		TMR1H = 0xFF;
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,409 :: 		T1CON.TMR1ON = 1;                                                        // Start counting TMR1 from 0
	BSF        T1CON+0, 0
;main.c,410 :: 		while(SENSOR_DATA);                                                      // Wait until data signal falls (high to low edge).
L_sensorReadByte65:
	BTFSS      RA0_bit+0, 0
	GOTO       L_sensorReadByte66
	GOTO       L_sensorReadByte65
L_sensorReadByte66:
;main.c,411 :: 		T1CON.TMR1ON = 0;                                                        // Stop the TMR1
	BCF        T1CON+0, 0
;main.c,413 :: 		if(TMR1L > 40)                                                           // If the pulse time > 40us, the received data is 1
	MOVF       TMR1L+0, 0
	SUBLW      40
	BTFSC      STATUS+0, 0
	GOTO       L_sensorReadByte67
;main.c,414 :: 		num |= 1<<(7-i);                                                      // Populate num with the corresponding sigan byte
	MOVF       R2+0, 0
	SUBLW      7
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      R1+0
	MOVLW      1
	MOVWF      R0+0
	MOVF       R1+0, 0
L__sensorReadByte84:
	BTFSC      STATUS+0, 2
	GOTO       L__sensorReadByte85
	RLF        R0+0, 1
	BCF        R0+0, 0
	ADDLW      255
	GOTO       L__sensorReadByte84
L__sensorReadByte85:
	MOVF       R0+0, 0
	IORWF      sensorReadByte_num_L0+0, 1
L_sensorReadByte67:
;main.c,404 :: 		for (i=0; i<8; i++){
	INCF       R2+0, 1
;main.c,415 :: 		}
	GOTO       L_sensorReadByte60
L_sensorReadByte61:
;main.c,416 :: 		return num;                                                                   // num returns 1 byte data
	MOVF       sensorReadByte_num_L0+0, 0
	MOVWF      R0+0
;main.c,417 :: 		}
	RETURN
; end of _sensorReadByte

_sendPWM:

;main.c,423 :: 		void sendPWM(){
;main.c,424 :: 		TXREG = 'n'; cleanBuffer();
	MOVLW      110
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,425 :: 		TXREG = '0'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,426 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,427 :: 		hmi_commonData();
	CALL       _hmi_commonData+0
;main.c,428 :: 		}
	RETURN
; end of _sendPWM

_sendData:

;main.c,434 :: 		void sendData(char val){
;main.c,435 :: 		TXREG = 'x'; cleanBuffer();
	MOVLW      120
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,436 :: 		TXREG = val; cleanBuffer();
	MOVF       FARG_sendData_val+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,437 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,438 :: 		hmi_commonData();
	CALL       _hmi_commonData+0
;main.c,439 :: 		}
	RETURN
; end of _sendData

_sendGraph:

;main.c,445 :: 		void sendGraph(char id){
;main.c,447 :: 		TXREG = 'g'; cleanBuffer();
	MOVLW      103
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,448 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,451 :: 		if(id == '0'){
	MOVF       FARG_sendGraph_id+0, 0
	XORLW      48
	BTFSS      STATUS+0, 2
	GOTO       L_sendGraph68
;main.c,452 :: 		TXREG = '0';
	MOVLW      48
	MOVWF      TXREG+0
;main.c,453 :: 		}
	GOTO       L_sendGraph69
L_sendGraph68:
;main.c,455 :: 		TXREG = '1';
	MOVLW      49
	MOVWF      TXREG+0
;main.c,456 :: 		}
L_sendGraph69:
;main.c,457 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,458 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,459 :: 		hmi_commonData();
	CALL       _hmi_commonData+0
;main.c,460 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,461 :: 		}
	RETURN
; end of _sendGraph

_errorState:

;main.c,467 :: 		void errorState(char id, char val){
;main.c,468 :: 		TXREG = 'e'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,469 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,470 :: 		TXREG = id; cleanBuffer();
	MOVF       FARG_errorState_id+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,471 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,472 :: 		TXREG = val; cleanBuffer();
	MOVF       FARG_errorState_val+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,473 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,474 :: 		}
	RETURN
; end of _errorState

_hmi_nameParameter:

;main.c,479 :: 		void hmi_nameParameter(){
;main.c,480 :: 		TXREG = '.'; cleanBuffer();
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,481 :: 		TXREG = 'v'; cleanBuffer();
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,482 :: 		TXREG = 'a'; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,483 :: 		TXREG = 'l'; cleanBuffer();
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,484 :: 		TXREG = '='; cleanBuffer();
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,485 :: 		}
	RETURN
; end of _hmi_nameParameter

_hmi_commonData:

;main.c,490 :: 		void hmi_commonData(){
;main.c,491 :: 		TXREG = TEMP[0]; cleanBuffer();
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,492 :: 		TXREG = TEMP[1]; cleanBuffer();
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,493 :: 		TXREG = TEMP[2]; cleanBuffer();
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,494 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,495 :: 		}
	RETURN
; end of _hmi_commonData

_hmi_endCommand:

;main.c,500 :: 		void hmi_endCommand(){
;main.c,501 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,502 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,503 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,504 :: 		}
	RETURN
; end of _hmi_endCommand

_cleanBuffer:

;main.c,509 :: 		void cleanBuffer(){
;main.c,510 :: 		while(!TRMT_bit);                                                            //while loop as long the buffer is not empty
L_cleanBuffer70:
	BTFSC      TRMT_bit+0, 1
	GOTO       L_cleanBuffer71
	GOTO       L_cleanBuffer70
L_cleanBuffer71:
;main.c,511 :: 		}
	RETURN
; end of _cleanBuffer
