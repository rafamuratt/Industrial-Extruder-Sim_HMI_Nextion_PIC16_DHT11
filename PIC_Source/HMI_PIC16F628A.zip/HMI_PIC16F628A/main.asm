
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;main.c,58 :: 		void interrupt(){
;main.c,59 :: 		if(RCIF_bit) {                                                              // Interrupt occurred on USART receive
	BTFSS      RCIF_bit+0, 5
	GOTO       L_interrupt0
;main.c,60 :: 		if(OERR_bit) {                                                          // Check for overrun error FIRST
	BTFSS      OERR_bit+0, 1
	GOTO       L_interrupt1
;main.c,61 :: 		CREN_bit = 0;                                                       // Reset the receiver logic
	BCF        CREN_bit+0, 4
;main.c,62 :: 		CREN_bit = 1;
	BSF        CREN_bit+0, 4
;main.c,63 :: 		REC = RCREG;                                                        // Clear the FIFO
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,64 :: 		return;                                                             // Exit interrupt handler
	RETURN
;main.c,65 :: 		}
L_interrupt1:
;main.c,67 :: 		if(FERR_bit) {                                                          // Check for framing error
	BTFSS      FERR_bit+0, 2
	GOTO       L_interrupt2
;main.c,68 :: 		REC = RCREG;                                                        // Discard the corrupted byte
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,69 :: 		return;
	RETURN
;main.c,70 :: 		}
L_interrupt2:
;main.c,72 :: 		REC = RCREG;                                                            // Read the data (clears RCIF_bit when finish)
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,74 :: 		if((REC >= '0' && REC <= '9')) {                                        // ONLY store characters that are numbers.
	MOVLW      48
	SUBWF      _REC+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt5
	MOVF       _REC+0, 0
	SUBLW      57
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt5
L__interrupt55:
;main.c,75 :: 		if(index < BUFFER_SIZE - 1) {
	MOVLW      3
	SUBWF      _index+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_interrupt6
;main.c,76 :: 		buffer[index++] = REC;                                             // Store received character
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	MOVF       _REC+0, 0
	MOVWF      INDF+0
	INCF       _index+0, 1
;main.c,77 :: 		buffer[index] = '\0';                                              // Null-terminate the string
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	CLRF       INDF+0
;main.c,78 :: 		}
L_interrupt6:
;main.c,79 :: 		}
L_interrupt5:
;main.c,81 :: 		if(index == 3){                                                         // Full string received (without null terminator)
	MOVF       _index+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt7
;main.c,82 :: 		if(strcmp(buffer, "300") == 0){                                     // "RUN" command received
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr1_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt59
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt59:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt8
;main.c,83 :: 		POWER = 1;
	BSF        RB5_bit+0, 5
;main.c,84 :: 		CCP1CON = 0x0C;                                                  // Restore PWM
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,85 :: 		uartDataReady = 1;                                               // Set flag to indicate data received
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,86 :: 		}
	GOTO       L_interrupt9
L_interrupt8:
;main.c,87 :: 		else if(strcmp(buffer, "400") == 0){                            // "STOP" command received
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr2_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt60
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt60:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt10
;main.c,88 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,89 :: 		CCP1CON = 0x00;                                              // Kill PWM
	CLRF       CCP1CON+0
;main.c,90 :: 		PWM_OUT = 0;                                                 // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,91 :: 		uartDataReady = 1;
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,92 :: 		}
	GOTO       L_interrupt11
L_interrupt10:
;main.c,94 :: 		else if(strcmp(buffer, "500") == 0){                            // "EMERGENCY STOP" command received
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr3_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt61
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt61:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt12
;main.c,95 :: 		POWER = 0;                                                   // Stop
	BCF        RB5_bit+0, 5
;main.c,96 :: 		CCP1CON = 0x00;                                              // Kill PWM
	CLRF       CCP1CON+0
;main.c,97 :: 		PWM_OUT = 0;                                                 // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,98 :: 		uartDataReady = 1;
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,99 :: 		}
	GOTO       L_interrupt13
L_interrupt12:
;main.c,102 :: 		strcpy(pwmBuffer, buffer);                                          // 0-100 = update pwmBuffer
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_strcpy_to+0
	MOVLW      _buffer+0
	MOVWF      FARG_strcpy_from+0
	CALL       _strcpy+0
;main.c,103 :: 		uartDataReady = 1;                                                  // Set flag to indicate data received
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,104 :: 		}
L_interrupt13:
L_interrupt11:
L_interrupt9:
;main.c,105 :: 		index = 0;                                                           // Reset buffer index for next string
	CLRF       _index+0
;main.c,106 :: 		}
L_interrupt7:
;main.c,107 :: 		}
L_interrupt0:
;main.c,109 :: 		if(PIR1.TMR1IF){                                                            // Interrupt after 256us (sensor time out)
	BTFSS      PIR1+0, 0
	GOTO       L_interrupt14
;main.c,110 :: 		PIR1.TMR1IF  = 0;                                                        // Clear the interrupt flag
	BCF        PIR1+0, 0
;main.c,111 :: 		TOUT = 1;                                                                // Set the time out flag
	MOVLW      1
	MOVWF      _TOUT+0
;main.c,112 :: 		T1CON.TMR1ON = 0;                                                        // Stop TMR1
	BCF        T1CON+0, 0
;main.c,113 :: 		SENSOR_DATA  = 1;                                                        // Set pin17 to HIGH
	BSF        RA0_bit+0, 0
;main.c,114 :: 		}
L_interrupt14:
;main.c,115 :: 		}
L__interrupt58:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

;main.c,118 :: 		void main() {
;main.c,120 :: 		CMCON       = 0x07;               // disable comparators
	MOVLW      7
	MOVWF      CMCON+0
;main.c,121 :: 		OPTION_REG  = 0x86;               // RBPU = 1 (PortB pull ups disabled) | PSA = 0 (Prescaler assign. Timer0| PS<2:0> = 110 (Prescaler 1:128)
	MOVLW      134
	MOVWF      OPTION_REG+0
;main.c,122 :: 		GIE_bit     = 0x01;               // bit 7 of INTCON register (Global Interrupt Enable bit)
	BSF        GIE_bit+0, 7
;main.c,123 :: 		PEIE_bit    = 0x01;               // bit 6 of INTCON register (Peripheral Interrupt Enable bit)
	BSF        PEIE_bit+0, 6
;main.c,125 :: 		PIE1.TMR1IE = 0x01;               // enable Timer1 interrupt
	BSF        PIE1+0, 0
;main.c,127 :: 		PR2         = 0xFF;               // starts the TMR2 overflow register at maximum count: 255
	MOVLW      255
	MOVWF      PR2+0
;main.c,128 :: 		T2CON       = 0x06;               // enable TMR2 and prescaler as 1:16
	MOVLW      6
	MOVWF      T2CON+0
;main.c,129 :: 		CCP1CON     = 0x0C;               // enable PWM  mode(12)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,130 :: 		CCPR1L      = 0x00;               // start the PWM in 0%
	CLRF       CCPR1L+0
;main.c,132 :: 		delay_ms(1000);                   // delay before start the USART
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main15:
	DECFSZ     R13+0, 1
	GOTO       L_main15
	DECFSZ     R12+0, 1
	GOTO       L_main15
	DECFSZ     R11+0, 1
	GOTO       L_main15
	NOP
	NOP
;main.c,133 :: 		RCIF_bit    = 0x00;               // clear the USART interruption flag (located at PIR1 register)
	BCF        RCIF_bit+0, 5
;main.c,134 :: 		RCIE_bit    = 0x01;               // enable UART interruption for data reception (located at PIE1 register)
	BSF        RCIE_bit+0, 5
;main.c,135 :: 		SPBRG       = 0x19;               // set USART (8 bits, no parity, 1 stop bit, 9600, asynchronous)
	MOVLW      25
	MOVWF      SPBRG+0
;main.c,136 :: 		TXEN_bit    = 0x01;               // enable transmission (TXSTA register)
	BSF        TXEN_bit+0, 5
;main.c,137 :: 		BRGH_bit    = 0x01;               // baudrate at high speed (TXSTA register)
	BSF        BRGH_bit+0, 2
;main.c,138 :: 		SYNC_bit    = 0x00;               // asynchronous mode (TXSTA register)
	BCF        SYNC_bit+0, 4
;main.c,139 :: 		SPEN_bit    = 0x01;               // enable serial port (RCSTA register)
	BSF        SPEN_bit+0, 7
;main.c,140 :: 		CREN_bit    = 0x01;               // enable continuous reception (RCSTA register)
	BSF        CREN_bit+0, 4
;main.c,142 :: 		TRISA       = 0x01;               // RA0 = input
	MOVLW      1
	MOVWF      TRISA+0
;main.c,143 :: 		PORTA       = 0x01;               // RA0 start in HIGH, the rest in LOW
	MOVLW      1
	MOVWF      PORTA+0
;main.c,144 :: 		TRISB       = 0x02;               // RB1 (RX) as input, the rest as output
	MOVLW      2
	MOVWF      TRISB+0
;main.c,145 :: 		PORTB       = 0x02;               // RB1 starts in HIGH, the rest in LOW
	MOVLW      2
	MOVWF      PORTB+0
;main.c,148 :: 		while(1){
L_main16:
;main.c,150 :: 		if(uartDataReady){
	MOVF       _uartDataReady+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main18
;main.c,151 :: 		PWM_VALUE = atoi(pwmBuffer);                                            // Update PWM_VALUE with the received string conv to int
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_atoi_s+0
	CALL       _atoi+0
	MOVF       R0+0, 0
	MOVWF      _PWM_VALUE+0
;main.c,152 :: 		uartDataReady = 0;
	CLRF       _uartDataReady+0
;main.c,153 :: 		PWM();
	CALL       _PWM+0
;main.c,154 :: 		}
L_main18:
;main.c,155 :: 		sensorTick++;
	INCF       _sensorTick+0, 1
	BTFSC      STATUS+0, 2
	INCF       _sensorTick+1, 1
;main.c,156 :: 		if(sensorTick > WAIT_TIME) {                                                // minimal time between DHT11 reading = 1s
	MOVF       _sensorTick+1, 0
	SUBLW      4
	BTFSS      STATUS+0, 2
	GOTO       L__main62
	MOVF       _sensorTick+0, 0
	SUBLW      176
L__main62:
	BTFSC      STATUS+0, 0
	GOTO       L_main19
;main.c,157 :: 		StartSignal();
	CALL       _StartSignal+0
;main.c,158 :: 		sensor();
	CALL       _sensor+0
;main.c,159 :: 		sensorTick = 0;
	CLRF       _sensorTick+0
	CLRF       _sensorTick+1
;main.c,160 :: 		}
L_main19:
;main.c,161 :: 		Delay_ms(1);
	MOVLW      2
	MOVWF      R12+0
	MOVLW      75
	MOVWF      R13+0
L_main20:
	DECFSZ     R13+0, 1
	GOTO       L_main20
	DECFSZ     R12+0, 1
	GOTO       L_main20
;main.c,162 :: 		}
	GOTO       L_main16
;main.c,163 :: 		}
	GOTO       $+0
; end of _main

_PWM:

;main.c,167 :: 		void PWM() {
;main.c,168 :: 		CCPR1L = PWM_VALUE;                                                            // the PWM output is updated
	MOVF       _PWM_VALUE+0, 0
	MOVWF      CCPR1L+0
;main.c,169 :: 		TEMP[0]= ((int)(PWM_VALUE/2.53)/100%10) + 48;                                  // Send variable data to IHM Nextion. 2.53 is only to convert into percentage at slider.
	MOVF       _PWM_VALUE+0, 0
	MOVWF      R0+0
	CALL       _Byte2Double+0
	MOVLW      133
	MOVWF      R4+0
	MOVLW      235
	MOVWF      R4+1
	MOVLW      33
	MOVWF      R4+2
	MOVLW      128
	MOVWF      R4+3
	CALL       _Div_32x32_FP+0
	CALL       _Double2Int+0
	MOVF       R0+0, 0
	MOVWF      FLOC__PWM+0
	MOVF       R0+1, 0
	MOVWF      FLOC__PWM+1
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,170 :: 		TEMP[1]= ((int)(PWM_VALUE/2.53)/10%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,171 :: 		TEMP[2]= ((int)(PWM_VALUE/2.53)%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,172 :: 		sendPWM();
	CALL       _sendPWM+0
;main.c,174 :: 		}
	RETURN
; end of _PWM

_StartSignal:

;main.c,177 :: 		void StartSignal(){
;main.c,178 :: 		DATA_DIR = 0;
	BCF        TRISA0_bit+0, 0
;main.c,179 :: 		SENSOR_DATA  = 0;
	BCF        RA0_bit+0, 0
;main.c,180 :: 		Delay_ms(18);    // Low for at least 18us     18
	MOVLW      24
	MOVWF      R12+0
	MOVLW      95
	MOVWF      R13+0
L_StartSignal21:
	DECFSZ     R13+0, 1
	GOTO       L_StartSignal21
	DECFSZ     R12+0, 1
	GOTO       L_StartSignal21
;main.c,181 :: 		SENSOR_DATA    = 1;
	BSF        RA0_bit+0, 0
;main.c,183 :: 		T1CON       = 0x00;               // prescaler 1:1, and Timer1 is off initially
	CLRF       T1CON+0
;main.c,184 :: 		PIR1.TMR1IF = 0x00;               // clear TMR INT Flag bit
	BCF        PIR1+0, 0
;main.c,185 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,186 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,187 :: 		T1CON.TMR1ON = 1;
	BSF        T1CON+0, 0
;main.c,189 :: 		if(TMR1L == 22){
	MOVF       TMR1L+0, 0
	XORLW      22
	BTFSS      STATUS+0, 2
	GOTO       L_StartSignal22
;main.c,190 :: 		DATA_DIR = 1;     // Data port is input
	BSF        TRISA0_bit+0, 0
;main.c,191 :: 		T1CON.TMR1ON = 0;
	BCF        T1CON+0, 0
;main.c,192 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,193 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,194 :: 		}
L_StartSignal22:
;main.c,195 :: 		}
	RETURN
; end of _StartSignal

_CheckResponse:

;main.c,198 :: 		unsigned short CheckResponse(){
;main.c,199 :: 		TOUT = 0;
	CLRF       _TOUT+0
;main.c,200 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,201 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,202 :: 		T1CON.TMR1ON = 1;                  // Start TMR1 while waiting for sensor response
	BSF        T1CON+0, 0
;main.c,204 :: 		while(!SENSOR_DATA && !TOUT);       // If there's no response within 256us, the Timer1 overflows
L_CheckResponse23:
	BTFSC      RA0_bit+0, 0
	GOTO       L_CheckResponse24
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse24
L__CheckResponse57:
	GOTO       L_CheckResponse23
L_CheckResponse24:
;main.c,205 :: 		if (TOUT)
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse27
;main.c,206 :: 		return 0;    // and exit
	CLRF       R0+0
	RETURN
L_CheckResponse27:
;main.c,209 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,210 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,211 :: 		while(SENSOR_DATA && !TOUT);
L_CheckResponse29:
	BTFSS      RA0_bit+0, 0
	GOTO       L_CheckResponse30
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse30
L__CheckResponse56:
	GOTO       L_CheckResponse29
L_CheckResponse30:
;main.c,212 :: 		if (TOUT)
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse33
;main.c,213 :: 		return 0;
	CLRF       R0+0
	RETURN
L_CheckResponse33:
;main.c,216 :: 		T1CON.TMR1ON = 0;
	BCF        T1CON+0, 0
;main.c,217 :: 		return 1;
	MOVLW      1
	MOVWF      R0+0
;main.c,220 :: 		}
	RETURN
; end of _CheckResponse

_ReadByte:

;main.c,223 :: 		unsigned short ReadByte(){
;main.c,224 :: 		unsigned short num = 0, i;
	CLRF       ReadByte_num_L0+0
;main.c,225 :: 		DATA_DIR = 1;
	BSF        TRISA0_bit+0, 0
;main.c,227 :: 		for (i=0; i<8; i++){
	CLRF       R2+0
L_ReadByte35:
	MOVLW      8
	SUBWF      R2+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte36
;main.c,228 :: 		while(!SENSOR_DATA);
L_ReadByte38:
	BTFSC      RA0_bit+0, 0
	GOTO       L_ReadByte39
	GOTO       L_ReadByte38
L_ReadByte39:
;main.c,229 :: 		TMR1L       = 0x00;                // Inicializa o TMR1L em 0
	CLRF       TMR1L+0
;main.c,230 :: 		TMR1H       = 0xFF;                // Inicializa o TMR1H em 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,231 :: 		T1CON.TMR1ON = 1;  // Start TMR2 from 0 when a low to high data pulse
	BSF        T1CON+0, 0
;main.c,232 :: 		while(SENSOR_DATA);       // is detected, and wait until it falls low again.
L_ReadByte40:
	BTFSS      RA0_bit+0, 0
	GOTO       L_ReadByte41
	GOTO       L_ReadByte40
L_ReadByte41:
;main.c,233 :: 		T1CON.TMR1ON = 0;  // Stop the TMR2 when the data pulse falls low.
	BCF        T1CON+0, 0
;main.c,235 :: 		if(TMR1L > 40)
	MOVF       TMR1L+0, 0
	SUBLW      40
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte42
;main.c,236 :: 		num |= 1<<(7-i);  // If time > 40us, Data is 1
	MOVF       R2+0, 0
	SUBLW      7
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      R1+0
	MOVLW      1
	MOVWF      R0+0
	MOVF       R1+0, 0
L__ReadByte63:
	BTFSC      STATUS+0, 2
	GOTO       L__ReadByte64
	RLF        R0+0, 1
	BCF        R0+0, 0
	ADDLW      255
	GOTO       L__ReadByte63
L__ReadByte64:
	MOVF       R0+0, 0
	IORWF      ReadByte_num_L0+0, 1
L_ReadByte42:
;main.c,227 :: 		for (i=0; i<8; i++){
	INCF       R2+0, 1
;main.c,237 :: 		}
	GOTO       L_ReadByte35
L_ReadByte36:
;main.c,238 :: 		return num;
	MOVF       ReadByte_num_L0+0, 0
	MOVWF      R0+0
;main.c,239 :: 		}
	RETURN
; end of _ReadByte

_sensor:

;main.c,242 :: 		void sensor(){
;main.c,245 :: 		check = CheckResponse();
	CALL       _CheckResponse+0
;main.c,247 :: 		if (!check){
	MOVF       R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensor43
;main.c,249 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,250 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,251 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,252 :: 		TXREG = '1'; cleanBuffer(); // Set er0 to 1 (NOK)
	MOVLW      49
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,253 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,255 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,256 :: 		CCP1CON = 0x00;                                                             // Kill PWM
	CLRF       CCP1CON+0
;main.c,257 :: 		PWM_OUT = 0;                                                                // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,258 :: 		}
	GOTO       L_sensor44
L_sensor43:
;main.c,261 :: 		RH_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte1+0
;main.c,262 :: 		RH_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte2+0
;main.c,263 :: 		T_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte1+0
;main.c,264 :: 		T_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte2+0
;main.c,265 :: 		CheckSum = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _CheckSum+0
;main.c,267 :: 		if (CheckSum == ((RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF)){
	MOVF       _RH_Byte2+0, 0
	ADDWF      _RH_Byte1+0, 0
	MOVWF      R1+0
	CLRF       R1+1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte1+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte2+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVLW      255
	ANDWF      R1+0, 0
	MOVWF      R3+0
	MOVF       R1+1, 0
	MOVWF      R3+1
	MOVLW      0
	ANDWF      R3+1, 1
	MOVLW      0
	XORWF      R3+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__sensor65
	MOVF       R3+0, 0
	XORWF      R0+0, 0
L__sensor65:
	BTFSS      STATUS+0, 2
	GOTO       L_sensor45
;main.c,269 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,270 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,271 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,272 :: 		TXREG = '0'; cleanBuffer(); // Set er0 to 0 (OK)
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,273 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,276 :: 		if(T_Byte1 > 2) T_Byte1 -= OFFSET_TEMP;   // Subtract 2 degrees
	MOVF       _T_Byte1+0, 0
	SUBLW      2
	BTFSC      STATUS+0, 0
	GOTO       L_sensor46
	MOVLW      2
	SUBWF      _T_Byte1+0, 1
	GOTO       L_sensor47
L_sensor46:
;main.c,277 :: 		else T_Byte1 = 0;              // Prevent negative rollover
	CLRF       _T_Byte1+0
L_sensor47:
;main.c,279 :: 		if(RH_Byte1 > 3) RH_Byte1 -= OFFSET_HUM; // Subtract 3 percent
	MOVF       _RH_Byte1+0, 0
	SUBLW      3
	BTFSC      STATUS+0, 0
	GOTO       L_sensor48
	MOVLW      7
	SUBWF      _RH_Byte1+0, 1
	GOTO       L_sensor49
L_sensor48:
;main.c,280 :: 		else RH_Byte1 = 0;             // Prevent negative rollover
	CLRF       _RH_Byte1+0
L_sensor49:
;main.c,283 :: 		TEMP[0] = RH_Byte1/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,284 :: 		TEMP[1] = RH_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,285 :: 		TEMP[2] = RH_Byte2/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte2+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,286 :: 		sendData('1');
	MOVLW      49
	MOVWF      FARG_sendData_num+0
	CALL       _sendData+0
;main.c,287 :: 		sendGraph('1', RH_Byte1);                                                 // Sends raw value (e.g., 40)
	MOVLW      49
	MOVWF      FARG_sendGraph_id+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      FARG_sendGraph_val+0
	CALL       _sendGraph+0
;main.c,291 :: 		TEMP[0] = T_Byte1/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,292 :: 		TEMP[1] = T_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,293 :: 		TEMP[2] = T_Byte2/10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte2+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,294 :: 		sendData('0');
	MOVLW      48
	MOVWF      FARG_sendData_num+0
	CALL       _sendData+0
;main.c,295 :: 		sendGraph('0', T_Byte1);                                                  // Sends raw value (e.g., 21)
	MOVLW      48
	MOVWF      FARG_sendGraph_id+0
	MOVF       _T_Byte1+0, 0
	MOVWF      FARG_sendGraph_val+0
	CALL       _sendGraph+0
;main.c,297 :: 		}
	GOTO       L_sensor50
L_sensor45:
;main.c,301 :: 		TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,302 :: 		TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,303 :: 		TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,304 :: 		TXREG = '0'; cleanBuffer(); // Set er0 to 0 (OK)
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,305 :: 		TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,306 :: 		}
L_sensor50:
;main.c,308 :: 		}
L_sensor44:
;main.c,310 :: 		}
	RETURN
; end of _sensor

_sendPWM:

;main.c,313 :: 		void sendPWM(){
;main.c,314 :: 		TXREG = 'n';                                                                 //Write in the UART: n0.val=
	MOVLW      110
	MOVWF      TXREG+0
;main.c,315 :: 		cleanBuffer();                                                               //where "n0" is the % field ID in the main page
	CALL       _cleanBuffer+0
;main.c,316 :: 		TXREG = '0';                                                                 //Send char
	MOVLW      48
	MOVWF      TXREG+0
;main.c,317 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,318 :: 		TXREG = '.';
	MOVLW      46
	MOVWF      TXREG+0
;main.c,319 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,320 :: 		TXREG = 'v';
	MOVLW      118
	MOVWF      TXREG+0
;main.c,321 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,322 :: 		TXREG = 'a';
	MOVLW      97
	MOVWF      TXREG+0
;main.c,323 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,324 :: 		TXREG = 'l';
	MOVLW      108
	MOVWF      TXREG+0
;main.c,325 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,326 :: 		TXREG = '=';
	MOVLW      61
	MOVWF      TXREG+0
;main.c,327 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,328 :: 		comData();
	CALL       _comData+0
;main.c,329 :: 		}
	RETURN
; end of _sendPWM

_sendData:

;main.c,332 :: 		void sendData(char num)                                                        //Write in the UART:  x"num".val=
;main.c,334 :: 		TXREG = 'x';                                                                 //Send char
	MOVLW      120
	MOVWF      TXREG+0
;main.c,335 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,336 :: 		TXREG = num;
	MOVF       FARG_sendData_num+0, 0
	MOVWF      TXREG+0
;main.c,337 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,338 :: 		TXREG = '.';
	MOVLW      46
	MOVWF      TXREG+0
;main.c,339 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,340 :: 		TXREG = 'v';
	MOVLW      118
	MOVWF      TXREG+0
;main.c,341 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,342 :: 		TXREG = 'a';
	MOVLW      97
	MOVWF      TXREG+0
;main.c,343 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,344 :: 		TXREG = 'l';
	MOVLW      108
	MOVWF      TXREG+0
;main.c,345 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,346 :: 		TXREG = '=';
	MOVLW      61
	MOVWF      TXREG+0
;main.c,347 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,348 :: 		comData();
	CALL       _comData+0
;main.c,349 :: 		}
	RETURN
; end of _sendData

_sendGraph:

;main.c,352 :: 		void sendGraph(char id, unsigned short val){
;main.c,353 :: 		TEMP[0] = (val / 100) + 48;       // Hundreds
	MOVLW      100
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,354 :: 		TEMP[1] = ((val / 10) % 10) + 48; // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,355 :: 		TEMP[2] = (val % 10) + 48;        // Units
	MOVLW      10
	MOVWF      R4+0
	MOVF       FARG_sendGraph_val+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,358 :: 		TXREG = 'g'; cleanBuffer();
	MOVLW      103
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,359 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,362 :: 		if(id == '0') { TXREG = '0';
	MOVF       FARG_sendGraph_id+0, 0
	XORLW      48
	BTFSS      STATUS+0, 2
	GOTO       L_sendGraph51
	MOVLW      48
	MOVWF      TXREG+0
;main.c,363 :: 		} else { TXREG = '1'; }
	GOTO       L_sendGraph52
L_sendGraph51:
	MOVLW      49
	MOVWF      TXREG+0
L_sendGraph52:
;main.c,364 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,367 :: 		TXREG = '.'; cleanBuffer();
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,368 :: 		TXREG = 'v'; cleanBuffer();
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,369 :: 		TXREG = 'a'; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,370 :: 		TXREG = 'l'; cleanBuffer();
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,371 :: 		TXREG = '='; cleanBuffer();
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,374 :: 		TXREG = TEMP[0]; cleanBuffer();
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,375 :: 		TXREG = TEMP[1]; cleanBuffer();
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,376 :: 		TXREG = TEMP[2]; cleanBuffer();
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,379 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,380 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,381 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,382 :: 		}
	RETURN
; end of _sendGraph

_comData:

;main.c,385 :: 		void comData()                                                                  //common measured data (can be temperature or humidity)
;main.c,387 :: 		TXREG = TEMP[0];                                                             //Send char
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
;main.c,388 :: 		cleanBuffer();                                                               //Wait for buffer cleaning
	CALL       _cleanBuffer+0
;main.c,389 :: 		TXREG = TEMP[1];
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
;main.c,390 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,391 :: 		TXREG = TEMP[2];
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
;main.c,392 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,393 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,394 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,395 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,396 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,397 :: 		TXREG = 0xFF;
	MOVLW      255
	MOVWF      TXREG+0
;main.c,398 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,399 :: 		}
	RETURN
; end of _comData

_cleanBuffer:

;main.c,402 :: 		void cleanBuffer()                                                              //Clean the buffer
;main.c,404 :: 		while(!TRMT_bit);                                                            //while loop until the buffer is not empty
L_cleanBuffer53:
	BTFSC      TRMT_bit+0, 1
	GOTO       L_cleanBuffer54
	GOTO       L_cleanBuffer53
L_cleanBuffer54:
;main.c,405 :: 		}
	RETURN
; end of _cleanBuffer
