
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

;main.c,66 :: 		void interrupt(){
;main.c,67 :: 		if(INTF_bit){
	BTFSS      INTF_bit+0, 1
	GOTO       L_interrupt0
;main.c,69 :: 		hardwareEmgState = 1;
	MOVLW      1
	MOVWF      _hardwareEmgState+0
;main.c,70 :: 		CCP1CON = 0x00;                                                         // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,71 :: 		PWM_OUT = 0;                                                            // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,72 :: 		POWER = 0;                                                              // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,73 :: 		INTF_bit = 0;                                                           // Clear the flag
	BCF        INTF_bit+0, 1
;main.c,74 :: 		}
L_interrupt0:
;main.c,76 :: 		if(!hardwareEmgState){                                                      // hw emergency is released
	MOVF       _hardwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt1
;main.c,77 :: 		if(RCIF_bit){
	BTFSS      RCIF_bit+0, 5
	GOTO       L_interrupt2
;main.c,79 :: 		if(OERR_bit){                                                       // Check for overrun error FIRST
	BTFSS      OERR_bit+0, 1
	GOTO       L_interrupt3
;main.c,80 :: 		CREN_bit = 0;                                                   // Reset the receiver logic
	BCF        CREN_bit+0, 4
;main.c,81 :: 		CREN_bit = 1;
	BSF        CREN_bit+0, 4
;main.c,82 :: 		REC = RCREG;                                                    // Clear the FIFO
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,83 :: 		return;                                                         // Exit interrupt handler
	RETURN
;main.c,84 :: 		}
L_interrupt3:
;main.c,86 :: 		if(FERR_bit){                                                       // Check for framing error
	BTFSS      FERR_bit+0, 2
	GOTO       L_interrupt4
;main.c,87 :: 		REC = RCREG;                                                    // Discard the corrupted byte
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,88 :: 		return;
	RETURN
;main.c,89 :: 		}
L_interrupt4:
;main.c,91 :: 		REC = RCREG;                                                        // Read the data (auto clear the RCIF_bit when finish)
	MOVF       RCREG+0, 0
	MOVWF      _REC+0
;main.c,93 :: 		if((REC >= '0' && REC <= '9')){                                     // ONLY store characters that are numbers.
	MOVLW      48
	SUBWF      _REC+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt7
	MOVF       _REC+0, 0
	SUBLW      57
	BTFSS      STATUS+0, 0
	GOTO       L_interrupt7
L__interrupt72:
;main.c,94 :: 		if(index < BUFFER_SIZE - 1){
	MOVLW      3
	SUBWF      _index+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_interrupt8
;main.c,95 :: 		buffer[index++] = REC;                                         // Store received character
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	MOVF       _REC+0, 0
	MOVWF      INDF+0
	INCF       _index+0, 1
;main.c,96 :: 		buffer[index] = '\0';                                          // Null-terminate the string
	MOVF       _index+0, 0
	ADDLW      _buffer+0
	MOVWF      FSR
	CLRF       INDF+0
;main.c,97 :: 		}
L_interrupt8:
;main.c,98 :: 		}
L_interrupt7:
;main.c,100 :: 		if(index == 3){                                                     // Full string received (without null terminator)
	MOVF       _index+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt9
;main.c,101 :: 		if(strcmp(buffer, "300") == 0){                                 // "RUN" command received "300"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr1_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt78
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt78:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt10
;main.c,102 :: 		CCP1CON = 0x0C;                                              // Set output, restore the PWM (if disabled)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,103 :: 		POWER = 1;                                                   // Run indicator = ON
	BSF        RB5_bit+0, 5
;main.c,104 :: 		}
	GOTO       L_interrupt11
L_interrupt10:
;main.c,106 :: 		else if(strcmp(buffer, "400") == 0){                            // "STOP" command received "400"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr2_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt79
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt79:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt12
;main.c,107 :: 		CCP1CON = 0x00;
	CLRF       CCP1CON+0
;main.c,108 :: 		PWM_OUT = 0;
	BCF        RB3_bit+0, 3
;main.c,109 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,110 :: 		}
	GOTO       L_interrupt13
L_interrupt12:
;main.c,112 :: 		else if(strcmp(buffer, "500") == 0){                            // "EMERGENCY STOP" command received "500"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr3_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt80
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt80:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt14
;main.c,113 :: 		softwareEmgState = 1;                                        // Set emergency flag
	MOVLW      1
	MOVWF      _softwareEmgState+0
;main.c,114 :: 		CCP1CON = 0x00;
	CLRF       CCP1CON+0
;main.c,115 :: 		PWM_OUT = 0;
	BCF        RB3_bit+0, 3
;main.c,116 :: 		POWER = 0;
	BCF        RB5_bit+0, 5
;main.c,117 :: 		}
	GOTO       L_interrupt15
L_interrupt14:
;main.c,119 :: 		else if(strcmp(buffer, "600") == 0){                            // "ACK" command received "600"
	MOVLW      _buffer+0
	MOVWF      FARG_strcmp_s1+0
	MOVLW      ?lstr4_main+0
	MOVWF      FARG_strcmp_s2+0
	CALL       _strcmp+0
	MOVLW      0
	XORWF      R0+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt81
	MOVLW      0
	XORWF      R0+0, 0
L__interrupt81:
	BTFSS      STATUS+0, 2
	GOTO       L_interrupt16
;main.c,120 :: 		if(sensorError){
	MOVF       _sensorError+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_interrupt17
;main.c,121 :: 		sensorError = 0;                                            // Clean the flag
	CLRF       _sensorError+0
;main.c,122 :: 		}
	GOTO       L_interrupt18
L_interrupt17:
;main.c,123 :: 		else asm goto 0x0000;                                        // If Emergency ACK, restart uC
	GOTO       0
L_interrupt18:
;main.c,124 :: 		}
	GOTO       L_interrupt19
L_interrupt16:
;main.c,126 :: 		else strcpy(pwmBuffer, buffer);                                 // 0-100 = update pwmBuffer
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_strcpy_to+0
	MOVLW      _buffer+0
	MOVWF      FARG_strcpy_from+0
	CALL       _strcpy+0
L_interrupt19:
L_interrupt15:
L_interrupt13:
L_interrupt11:
;main.c,127 :: 		uartDataReady = 1;                                              // Set flag to indicate data received
	MOVLW      1
	MOVWF      _uartDataReady+0
;main.c,128 :: 		index = 0;                                                      // Reset buffer index for next string
	CLRF       _index+0
;main.c,129 :: 		}
L_interrupt9:
;main.c,130 :: 		}
L_interrupt2:
;main.c,132 :: 		if(PIR1.TMR1IF){
	BTFSS      PIR1+0, 0
	GOTO       L_interrupt20
;main.c,134 :: 		PIR1.TMR1IF  = 0;                                                    // Clear the interrupt flag
	BCF        PIR1+0, 0
;main.c,135 :: 		TOUT = 1;                                                            // Set the time out flag
	MOVLW      1
	MOVWF      _TOUT+0
;main.c,136 :: 		T1CON.TMR1ON = 0;                                                    // Stop TMR1
	BCF        T1CON+0, 0
;main.c,137 :: 		SENSOR_DATA  = 1;                                                    // Set pin17 to HIGH
	BSF        RA0_bit+0, 0
;main.c,138 :: 		}
L_interrupt20:
;main.c,139 :: 		}
L_interrupt1:
;main.c,140 :: 		}
L__interrupt77:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

;main.c,144 :: 		void main(){
;main.c,145 :: 		CMCON       = 0x07;                                                      // Disable comparators
	MOVLW      7
	MOVWF      CMCON+0
;main.c,146 :: 		OPTION_REG  = 0x86;                                                      // RBPU = 1 (PortB pull ups disabled)| INTEDG = 0 (RB0/INT falling edge9 | PSA = 0 (Prescaler Timer0| PS<2:0> = 110 (Prescaler 1:128)
	MOVLW      134
	MOVWF      OPTION_REG+0
;main.c,147 :: 		INTE_bit    = 0x01;                                                      // Enable external interrup for emergency hw check
	BSF        INTE_bit+0, 4
;main.c,148 :: 		GIE_bit     = 0x01;                                                      // Bit 7 of INTCON register (Global Interrupt Enable bit)
	BSF        GIE_bit+0, 7
;main.c,149 :: 		PEIE_bit    = 0x01;                                                      // Bit 6 of INTCON register (Peripheral Interrupt Enable bit)
	BSF        PEIE_bit+0, 6
;main.c,151 :: 		PIE1.TMR1IE = 0x01;                                                      // Enable Timer1 interrupt
	BSF        PIE1+0, 0
;main.c,153 :: 		PR2         = 0xFF;                                                      // Starts the TMR2 overflow register in the maximum count: 255
	MOVLW      255
	MOVWF      PR2+0
;main.c,154 :: 		T2CON       = 0x06;                                                      // Enable TMR2 and prescaler as 1:16
	MOVLW      6
	MOVWF      T2CON+0
;main.c,155 :: 		CCP1CON     = 0x0C;                                                      // Enable PWM  mode(12)
	MOVLW      12
	MOVWF      CCP1CON+0
;main.c,156 :: 		CCPR1L      = 0x00;                                                      // Start the PWM in 0%
	CLRF       CCPR1L+0
;main.c,158 :: 		delay_ms(1000);                                                          // Delay before start the USART
	MOVLW      6
	MOVWF      R11+0
	MOVLW      19
	MOVWF      R12+0
	MOVLW      173
	MOVWF      R13+0
L_main21:
	DECFSZ     R13+0, 1
	GOTO       L_main21
	DECFSZ     R12+0, 1
	GOTO       L_main21
	DECFSZ     R11+0, 1
	GOTO       L_main21
	NOP
	NOP
;main.c,159 :: 		RCIF_bit    = 0x00;                                                      // Clear the USART interruption flag (located at PIR1 register)
	BCF        RCIF_bit+0, 5
;main.c,160 :: 		RCIE_bit    = 0x01;                                                      // Enable UART interruption for data reception (located at PIE1 register)
	BSF        RCIE_bit+0, 5
;main.c,162 :: 		SPBRG       = 0x19;                                                      // Set USART (8 bits, no parity, 1 stop bit, 9600, asynchronous)
	MOVLW      25
	MOVWF      SPBRG+0
;main.c,163 :: 		TXEN_bit    = 0x01;                                                      // Enable transmission (TXSTA register)
	BSF        TXEN_bit+0, 5
;main.c,164 :: 		BRGH_bit    = 0x01;                                                      // Baudrate at high speed (TXSTA register)
	BSF        BRGH_bit+0, 2
;main.c,165 :: 		SYNC_bit    = 0x00;                                                      // Asynchronous mode (TXSTA register)
	BCF        SYNC_bit+0, 4
;main.c,166 :: 		SPEN_bit    = 0x01;                                                      // Enable serial port (RCSTA register)
	BSF        SPEN_bit+0, 7
;main.c,167 :: 		CREN_bit    = 0x01;                                                      // Enable continuous reception (RCSTA register)
	BSF        CREN_bit+0, 4
;main.c,169 :: 		TRISA       = 0x01;                                                      // RA0 = input
	MOVLW      1
	MOVWF      TRISA+0
;main.c,170 :: 		PORTA       = 0x01;                                                      // RA0 start in HIGH, the rest in LOW
	MOVLW      1
	MOVWF      PORTA+0
;main.c,171 :: 		TRISB       = 0x03;                                                      // RB1 (RX) as input, the rest as output
	MOVLW      3
	MOVWF      TRISB+0
;main.c,172 :: 		PORTB       = 0x03;                                                      // RB1 starts in HIGH, the rest in LOW
	MOVLW      3
	MOVWF      PORTB+0
;main.c,174 :: 		if (EMG == 0) hardwareEmgState = 1;                                      // Only start if the emergency button is released
	BTFSC      RB0_bit+0, 0
	GOTO       L_main22
	MOVLW      1
	MOVWF      _hardwareEmgState+0
	GOTO       L_main23
L_main22:
;main.c,177 :: 		TXREG = 'r'; cleanBuffer();                                          // Send "res.val=1" (flag to indicate the PIC reset to the HMI)
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,178 :: 		TXREG = 'e'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,179 :: 		TXREG = 's'; cleanBuffer();
	MOVLW      115
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,180 :: 		hmi_nameParameter();                                                 // ".val="
	CALL       _hmi_nameParameter+0
;main.c,181 :: 		TXREG = '1'; cleanBuffer();
	MOVLW      49
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,182 :: 		hmi_endCommand();                                                    // "0xFF 0xFF 0xFF" (end of Nextion command)
	CALL       _hmi_endCommand+0
;main.c,183 :: 		}
L_main23:
;main.c,185 :: 		while(1){
L_main24:
;main.c,186 :: 		if(!softwareEmgState && !hardwareEmgState){
	MOVF       _softwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main28
	MOVF       _hardwareEmgState+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main28
L__main73:
;main.c,187 :: 		if(uartDataReady){
	MOVF       _uartDataReady+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main29
;main.c,188 :: 		PWM_VALUE = atoi(pwmBuffer);                                  // Update PWM_VALUE with the received string (converted to int)
	MOVLW      _pwmBuffer+0
	MOVWF      FARG_atoi_s+0
	CALL       _atoi+0
	MOVF       R0+0, 0
	MOVWF      _PWM_VALUE+0
;main.c,189 :: 		uartDataReady = 0;
	CLRF       _uartDataReady+0
;main.c,190 :: 		PWM();
	CALL       _PWM+0
;main.c,191 :: 		}
L_main29:
;main.c,192 :: 		sensorTick++;
	INCF       _sensorTick+0, 1
	BTFSC      STATUS+0, 2
	INCF       _sensorTick+1, 1
;main.c,193 :: 		if(sensorTick > WAIT_TIME){                                      // minimal time between DHT11 reading = 1s
	MOVF       _sensorTick+1, 0
	SUBLW      4
	BTFSS      STATUS+0, 2
	GOTO       L__main82
	MOVF       _sensorTick+0, 0
	SUBLW      176
L__main82:
	BTFSC      STATUS+0, 0
	GOTO       L_main30
;main.c,194 :: 		StartSignal();
	CALL       _StartSignal+0
;main.c,195 :: 		sensor();
	CALL       _sensor+0
;main.c,196 :: 		sensorTick = 0;
	CLRF       _sensorTick+0
	CLRF       _sensorTick+1
;main.c,197 :: 		}
L_main30:
;main.c,198 :: 		}
	GOTO       L_main31
L_main28:
;main.c,201 :: 		CCP1CON = 0x00;                                                  // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,202 :: 		PWM_OUT = 0;                                                     // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,203 :: 		POWER = 0;                                                       // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,205 :: 		while(1){                                                        // Force emergency release + reset
L_main32:
;main.c,206 :: 		errorState('1','1');                                           // Tell HMI there is emergency error sending: "er1.val=1"
	MOVLW      49
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,207 :: 		delay_ms(500);
	MOVLW      3
	MOVWF      R11+0
	MOVLW      138
	MOVWF      R12+0
	MOVLW      85
	MOVWF      R13+0
L_main34:
	DECFSZ     R13+0, 1
	GOTO       L_main34
	DECFSZ     R12+0, 1
	GOTO       L_main34
	DECFSZ     R11+0, 1
	GOTO       L_main34
	NOP
	NOP
;main.c,208 :: 		}
	GOTO       L_main32
;main.c,209 :: 		}
L_main31:
;main.c,210 :: 		Delay_ms(1);
	MOVLW      2
	MOVWF      R12+0
	MOVLW      75
	MOVWF      R13+0
L_main35:
	DECFSZ     R13+0, 1
	GOTO       L_main35
	DECFSZ     R12+0, 1
	GOTO       L_main35
;main.c,211 :: 		}
	GOTO       L_main24
;main.c,212 :: 		}
	GOTO       $+0
; end of _main

_PWM:

;main.c,217 :: 		void PWM(){
;main.c,218 :: 		CCPR1L = PWM_VALUE;                                                        // The PWM output is updated. "2.53" is to convert one byte into percentage (for PWM slider h0).
	MOVF       _PWM_VALUE+0, 0
	MOVWF      CCPR1L+0
;main.c,219 :: 		TEMP[0]= ((int)(PWM_VALUE/2.53)/100%10) + 48;                              // Hundreds
	MOVF       _PWM_VALUE+0, 0
	MOVWF      R0+0
	CALL       _Byte2Double+0
	MOVLW      133
	MOVWF      R4+0
	MOVLW      235
	MOVWF      R4+1
	MOVLW      33
	MOVWF      R4+2
	MOVLW      128
	MOVWF      R4+3
	CALL       _Div_32x32_FP+0
	CALL       _Double2Int+0
	MOVF       R0+0, 0
	MOVWF      FLOC__PWM+0
	MOVF       R0+1, 0
	MOVWF      FLOC__PWM+1
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,220 :: 		TEMP[1]= ((int)(PWM_VALUE/2.53)/10%10) + 48;                               // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,221 :: 		TEMP[2]= ((int)(PWM_VALUE/2.53)%10) + 48;                                  // Units
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FLOC__PWM+0, 0
	MOVWF      R0+0
	MOVF       FLOC__PWM+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_S+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,222 :: 		sendPWM();
	CALL       _sendPWM+0
;main.c,223 :: 		}
	RETURN
; end of _PWM

_StartSignal:

;main.c,228 :: 		void StartSignal(){
;main.c,229 :: 		DATA_DIR = 0;                                                             // Set TRISA0 as output
	BCF        TRISA0_bit+0, 0
;main.c,231 :: 		SENSOR_DATA = 0;                                                          // Low on pin17 (DHT11)
	BCF        RA0_bit+0, 0
;main.c,232 :: 		Delay_ms(18);                                                             // Keep low least 18us, the sensor detect the MCU "request signal"
	MOVLW      24
	MOVWF      R12+0
	MOVLW      95
	MOVWF      R13+0
L_StartSignal36:
	DECFSZ     R13+0, 1
	GOTO       L_StartSignal36
	DECFSZ     R12+0, 1
	GOTO       L_StartSignal36
;main.c,233 :: 		SENSOR_DATA = 1;                                                          // High
	BSF        RA0_bit+0, 0
;main.c,235 :: 		T1CON = 0x00;                                                             // Prescaler 1:1, and Timer1 is off initially
	CLRF       T1CON+0
;main.c,236 :: 		PIR1.TMR1IF = 0x00;                                                       // Clear TMR INT Flag bit
	BCF        PIR1+0, 0
;main.c,237 :: 		TMR1L = 0x00;                                                             // Set TMR1L = 0
	CLRF       TMR1L+0
;main.c,238 :: 		TMR1H = 0xFF;                                                             // Set TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,239 :: 		T1CON.TMR1ON = 1;                                                         // Start Timer1 to keep the MCU pulse high during ca. 22us
	BSF        T1CON+0, 0
;main.c,241 :: 		if(TMR1L == 22){                                                          // After 22us, reset timers (preparation to receive the sensor "response signal")
	MOVF       TMR1L+0, 0
	XORLW      22
	BTFSS      STATUS+0, 2
	GOTO       L_StartSignal37
;main.c,242 :: 		DATA_DIR = 1;                                                          // Set TRISA0 as input
	BSF        TRISA0_bit+0, 0
;main.c,243 :: 		SENSOR_DATA = 0;                                                       // Low on pin17 (DHT11)
	BCF        RA0_bit+0, 0
;main.c,244 :: 		T1CON.TMR1ON = 0;                                                      // Stop Timer1
	BCF        T1CON+0, 0
;main.c,245 :: 		TMR1L = 0x00;                                                          // Reset TMR1L = 0
	CLRF       TMR1L+0
;main.c,246 :: 		TMR1H = 0xFF;                                                          // Reset TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,247 :: 		}
L_StartSignal37:
;main.c,248 :: 		}
	RETURN
; end of _StartSignal

_sensor:

;main.c,253 :: 		void sensor(){
;main.c,256 :: 		check = CheckResponse();                                                      // When the sensor is OK, check = 1
	CALL       _CheckResponse+0
;main.c,258 :: 		if (!check){
	MOVF       R0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensor38
;main.c,259 :: 		errorState('0','1');                                                        // SENSOR TIMEOUT: Tell HMI there is a sensor error sending: "er0.val=1"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,260 :: 		CCP1CON = 0x00;                                                             // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,261 :: 		PWM_OUT = 0;                                                                // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,262 :: 		POWER = 0;                                                                  // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,263 :: 		sensorError = 1;                                                            // Sensor in error state
	MOVLW      1
	MOVWF      _sensorError+0
;main.c,264 :: 		}
	GOTO       L_sensor39
L_sensor38:
;main.c,268 :: 		RH_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte1+0
;main.c,269 :: 		RH_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _RH_Byte2+0
;main.c,270 :: 		T_Byte1 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte1+0
;main.c,271 :: 		T_Byte2 = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _T_Byte2+0
;main.c,272 :: 		CheckSum = ReadByte();
	CALL       _ReadByte+0
	MOVF       R0+0, 0
	MOVWF      _CheckSum+0
;main.c,275 :: 		if ((CheckSum == (RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF) && !sensorError){ // Force ACK to clear "!errorSensor"
	MOVF       _RH_Byte2+0, 0
	ADDWF      _RH_Byte1+0, 0
	MOVWF      R1+0
	CLRF       R1+1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte1+0, 0
	ADDWF      R1+0, 1
	BTFSC      STATUS+0, 0
	INCF       R1+1, 1
	MOVF       _T_Byte2+0, 0
	ADDWF      R1+0, 0
	MOVWF      R3+0
	MOVF       R1+1, 0
	BTFSC      STATUS+0, 0
	ADDLW      1
	MOVWF      R3+1
	MOVLW      0
	XORWF      R3+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__sensor83
	MOVF       R3+0, 0
	XORWF      R0+0, 0
L__sensor83:
	MOVLW      1
	BTFSS      STATUS+0, 2
	MOVLW      0
	MOVWF      R1+0
	MOVLW      255
	ANDWF      R1+0, 0
	MOVWF      R0+0
	BTFSC      STATUS+0, 2
	GOTO       L_sensor42
	MOVF       _sensorError+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_sensor42
L__sensor74:
;main.c,276 :: 		errorState('0','0');                                                  // SUCCESS: send to HMI: "er0.val=0"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      48
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,279 :: 		if(T_Byte1 > OFFSET_TEMP) T_Byte1 -= OFFSET_TEMP;                     // Subtract the offset
	MOVF       _T_Byte1+0, 0
	SUBLW      2
	BTFSC      STATUS+0, 0
	GOTO       L_sensor43
	MOVLW      2
	SUBWF      _T_Byte1+0, 1
	GOTO       L_sensor44
L_sensor43:
;main.c,280 :: 		else T_Byte1 = 0;                                                     // Prevent negative rollover
	CLRF       _T_Byte1+0
L_sensor44:
;main.c,282 :: 		if(RH_Byte1 > OFFSET_HUM) RH_Byte1 -= OFFSET_HUM;                     // Subtract the offset
	MOVF       _RH_Byte1+0, 0
	SUBLW      7
	BTFSC      STATUS+0, 0
	GOTO       L_sensor45
	MOVLW      7
	SUBWF      _RH_Byte1+0, 1
	GOTO       L_sensor46
L_sensor45:
;main.c,283 :: 		else RH_Byte1 = 0;                                                    // Prevent negative rollover
	CLRF       _RH_Byte1+0
L_sensor46:
;main.c,286 :: 		TEMP[0] = RH_Byte1/100 + 48;                                          // Hundreds
	MOVLW      100
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,287 :: 		TEMP[1] = ((RH_Byte1/10)%10) + 48;                                    // Tens
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,288 :: 		TEMP[2] = RH_Byte1%10 + 48;                                           // Units
	MOVLW      10
	MOVWF      R4+0
	MOVF       _RH_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,289 :: 		sendData('1');
	MOVLW      49
	MOVWF      FARG_sendData_val+0
	CALL       _sendData+0
;main.c,290 :: 		sendGraph('1');
	MOVLW      49
	MOVWF      FARG_sendGraph_id+0
	CALL       _sendGraph+0
;main.c,293 :: 		TEMP[0] = T_Byte1/100 + 48;
	MOVLW      100
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+0
;main.c,294 :: 		TEMP[1] = ((T_Byte1/10)%10) + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVLW      10
	MOVWF      R4+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+1
;main.c,295 :: 		TEMP[2] = T_Byte1%10 + 48;
	MOVLW      10
	MOVWF      R4+0
	MOVF       _T_Byte1+0, 0
	MOVWF      R0+0
	CALL       _Div_8x8_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVLW      48
	ADDWF      R0+0, 0
	MOVWF      _TEMP+2
;main.c,296 :: 		sendData('0');
	MOVLW      48
	MOVWF      FARG_sendData_val+0
	CALL       _sendData+0
;main.c,297 :: 		sendGraph('0');
	MOVLW      48
	MOVWF      FARG_sendGraph_id+0
	CALL       _sendGraph+0
;main.c,299 :: 		}
	GOTO       L_sensor47
L_sensor42:
;main.c,303 :: 		errorState('0', '1');                                               // Tell HMI there is a sensor error sending: "er0.val=1"
	MOVLW      48
	MOVWF      FARG_errorState_id+0
	MOVLW      49
	MOVWF      FARG_errorState_val+0
	CALL       _errorState+0
;main.c,304 :: 		CCP1CON = 0x00;                                                     // Cut the output (Kill PWM)
	CLRF       CCP1CON+0
;main.c,305 :: 		PWM_OUT = 0;                                                        // Ensure 0V
	BCF        RB3_bit+0, 3
;main.c,306 :: 		POWER = 0;                                                          // Run indicator = OFF
	BCF        RB5_bit+0, 5
;main.c,307 :: 		sensorError = 1;                                                    // Sensor in error state
	MOVLW      1
	MOVWF      _sensorError+0
;main.c,308 :: 		}
L_sensor47:
;main.c,309 :: 		}
L_sensor39:
;main.c,310 :: 		}
	RETURN
; end of _sensor

_CheckResponse:

;main.c,315 :: 		unsigned short CheckResponse(){
;main.c,316 :: 		TOUT = 0;                                                                 // Reset Time Out flag
	CLRF       _TOUT+0
;main.c,317 :: 		T1CON.TMR1ON = 1;                                                         // Start TMR1 (previoulsy reseted in startSignal()
	BSF        T1CON+0, 0
;main.c,319 :: 		while(!SENSOR_DATA && !TOUT);                                             // Wait for the "sensor response" on pin17 (high pulse from sensor, of ca. 80us)
L_CheckResponse48:
	BTFSC      RA0_bit+0, 0
	GOTO       L_CheckResponse49
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse49
L__CheckResponse76:
	GOTO       L_CheckResponse48
L_CheckResponse49:
;main.c,320 :: 		if(TOUT)                                                                  // If there's no response within 256us, the Timer1 overflows, Time Out
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse52
;main.c,321 :: 		return 0;                                                              // Sensor data is NOK, exit
	CLRF       R0+0
	RETURN
L_CheckResponse52:
;main.c,324 :: 		TMR1L = 0x00;                                                         // Reset TMR1L = 0
	CLRF       TMR1L+0
;main.c,325 :: 		TMR1H = 0xFF;                                                         // Reset TMR1H = 255
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,327 :: 		while(SENSOR_DATA && !TOUT);                                          // Wait for the "sensor data" on pin17
L_CheckResponse54:
	BTFSS      RA0_bit+0, 0
	GOTO       L_CheckResponse55
	MOVF       _TOUT+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_CheckResponse55
L__CheckResponse75:
	GOTO       L_CheckResponse54
L_CheckResponse55:
;main.c,328 :: 		if(TOUT)                                                              // If nothing comes within 256us, the Timer1 overflows, Time Out
	MOVF       _TOUT+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_CheckResponse58
;main.c,329 :: 		return 0;                                                          // Sensor data is NOK, exit
	CLRF       R0+0
	RETURN
L_CheckResponse58:
;main.c,332 :: 		T1CON.TMR1ON = 0;                                                    // Stop Timer1
	BCF        T1CON+0, 0
;main.c,333 :: 		return 1;                                                            // Sensor data is OK, return
	MOVLW      1
	MOVWF      R0+0
;main.c,336 :: 		}
	RETURN
; end of _CheckResponse

_ReadByte:

;main.c,341 :: 		unsigned short ReadByte(){
;main.c,342 :: 		unsigned short num = 0, i;
	CLRF       ReadByte_num_L0+0
;main.c,343 :: 		DATA_DIR = 1;                                                                 // Set TRISA0 as input
	BSF        TRISA0_bit+0, 0
;main.c,345 :: 		for (i=0; i<8; i++){
	CLRF       R2+0
L_ReadByte60:
	MOVLW      8
	SUBWF      R2+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte61
;main.c,346 :: 		while(!SENSOR_DATA);                                                     // Wait until the first data trasition (low to high edge) comes
L_ReadByte63:
	BTFSC      RA0_bit+0, 0
	GOTO       L_ReadByte64
	GOTO       L_ReadByte63
L_ReadByte64:
;main.c,348 :: 		TMR1L = 0x00;                                                            // Reset timers
	CLRF       TMR1L+0
;main.c,349 :: 		TMR1H = 0xFF;
	MOVLW      255
	MOVWF      TMR1H+0
;main.c,350 :: 		T1CON.TMR1ON = 1;                                                        // Start counting TMR1 from 0
	BSF        T1CON+0, 0
;main.c,351 :: 		while(SENSOR_DATA);                                                      // Wait until data signal falls (high to low edge).
L_ReadByte65:
	BTFSS      RA0_bit+0, 0
	GOTO       L_ReadByte66
	GOTO       L_ReadByte65
L_ReadByte66:
;main.c,352 :: 		T1CON.TMR1ON = 0;                                                        // Stop the TMR1
	BCF        T1CON+0, 0
;main.c,354 :: 		if(TMR1L > 40)                                                           // If the pulse time > 40us, the received data is 1
	MOVF       TMR1L+0, 0
	SUBLW      40
	BTFSC      STATUS+0, 0
	GOTO       L_ReadByte67
;main.c,355 :: 		num |= 1<<(7-i);                                                      // Populate num with the corresponding sigan byte
	MOVF       R2+0, 0
	SUBLW      7
	MOVWF      R0+0
	MOVF       R0+0, 0
	MOVWF      R1+0
	MOVLW      1
	MOVWF      R0+0
	MOVF       R1+0, 0
L__ReadByte84:
	BTFSC      STATUS+0, 2
	GOTO       L__ReadByte85
	RLF        R0+0, 1
	BCF        R0+0, 0
	ADDLW      255
	GOTO       L__ReadByte84
L__ReadByte85:
	MOVF       R0+0, 0
	IORWF      ReadByte_num_L0+0, 1
L_ReadByte67:
;main.c,345 :: 		for (i=0; i<8; i++){
	INCF       R2+0, 1
;main.c,356 :: 		}
	GOTO       L_ReadByte60
L_ReadByte61:
;main.c,357 :: 		return num;                                                                   // num returns 1 byte data
	MOVF       ReadByte_num_L0+0, 0
	MOVWF      R0+0
;main.c,358 :: 		}
	RETURN
; end of _ReadByte

_sendPWM:

;main.c,364 :: 		void sendPWM(){
;main.c,365 :: 		TXREG = 'n'; cleanBuffer();
	MOVLW      110
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,366 :: 		TXREG = '0'; cleanBuffer();
	MOVLW      48
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,367 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,368 :: 		commonData();
	CALL       _commonData+0
;main.c,369 :: 		}
	RETURN
; end of _sendPWM

_sendData:

;main.c,375 :: 		void sendData(char val){
;main.c,376 :: 		TXREG = 'x'; cleanBuffer();
	MOVLW      120
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,377 :: 		TXREG = val; cleanBuffer();
	MOVF       FARG_sendData_val+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,378 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,379 :: 		commonData();
	CALL       _commonData+0
;main.c,380 :: 		}
	RETURN
; end of _sendData

_sendGraph:

;main.c,386 :: 		void sendGraph(char id){
;main.c,388 :: 		TXREG = 'g'; cleanBuffer();
	MOVLW      103
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,389 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,392 :: 		if(id == '0'){
	MOVF       FARG_sendGraph_id+0, 0
	XORLW      48
	BTFSS      STATUS+0, 2
	GOTO       L_sendGraph68
;main.c,393 :: 		TXREG = '0';
	MOVLW      48
	MOVWF      TXREG+0
;main.c,394 :: 		}
	GOTO       L_sendGraph69
L_sendGraph68:
;main.c,396 :: 		TXREG = '1';
	MOVLW      49
	MOVWF      TXREG+0
;main.c,397 :: 		}
L_sendGraph69:
;main.c,398 :: 		cleanBuffer();
	CALL       _cleanBuffer+0
;main.c,399 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,400 :: 		commonData();
	CALL       _commonData+0
;main.c,401 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,402 :: 		}
	RETURN
; end of _sendGraph

_errorState:

;main.c,408 :: 		void errorState(char id, char val){
;main.c,409 :: 		TXREG = 'e'; cleanBuffer();
	MOVLW      101
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,410 :: 		TXREG = 'r'; cleanBuffer();
	MOVLW      114
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,411 :: 		TXREG = id; cleanBuffer();
	MOVF       FARG_errorState_id+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,412 :: 		hmi_nameParameter();
	CALL       _hmi_nameParameter+0
;main.c,413 :: 		TXREG = val; cleanBuffer();
	MOVF       FARG_errorState_val+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,414 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,415 :: 		}
	RETURN
; end of _errorState

_hmi_nameParameter:

;main.c,420 :: 		void hmi_nameParameter(){
;main.c,421 :: 		TXREG = '.'; cleanBuffer();
	MOVLW      46
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,422 :: 		TXREG = 'v'; cleanBuffer();
	MOVLW      118
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,423 :: 		TXREG = 'a'; cleanBuffer();
	MOVLW      97
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,424 :: 		TXREG = 'l'; cleanBuffer();
	MOVLW      108
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,425 :: 		TXREG = '='; cleanBuffer();
	MOVLW      61
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,426 :: 		}
	RETURN
; end of _hmi_nameParameter

_commonData:

;main.c,431 :: 		void commonData(){
;main.c,432 :: 		TXREG = TEMP[0]; cleanBuffer();
	MOVF       _TEMP+0, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,433 :: 		TXREG = TEMP[1]; cleanBuffer();
	MOVF       _TEMP+1, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,434 :: 		TXREG = TEMP[2]; cleanBuffer();
	MOVF       _TEMP+2, 0
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,435 :: 		hmi_endCommand();
	CALL       _hmi_endCommand+0
;main.c,436 :: 		}
	RETURN
; end of _commonData

_hmi_endCommand:

;main.c,441 :: 		void hmi_endCommand(){
;main.c,442 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,443 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,444 :: 		TXREG = 0xFF; cleanBuffer();
	MOVLW      255
	MOVWF      TXREG+0
	CALL       _cleanBuffer+0
;main.c,445 :: 		}
	RETURN
; end of _hmi_endCommand

_cleanBuffer:

;main.c,450 :: 		void cleanBuffer(){
;main.c,451 :: 		while(!TRMT_bit);                                                            //while loop as long the buffer is not empty
L_cleanBuffer70:
	BTFSC      TRMT_bit+0, 1
	GOTO       L_cleanBuffer71
	GOTO       L_cleanBuffer70
L_cleanBuffer71:
;main.c,452 :: 		}
	RETURN
; end of _cleanBuffer
