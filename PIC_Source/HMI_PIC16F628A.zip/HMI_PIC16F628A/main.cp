#line 1 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/zGeral/1Concluidos/Eng. Josias/Display Nextion/HMI Common Files/Application/HMI_PIC16F628A/main.c"
#line 21 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/zGeral/1Concluidos/Eng. Josias/Display Nextion/HMI Common Files/Application/HMI_PIC16F628A/main.c"
sbit sensorData at RA0_bit;
sbit oven at RB5_bit;
sbit DataDir at TRISA0_bit;






void PWM();
void StartSignal();
unsigned short CheckResponse();
unsigned short ReadByte();
void sensor();
void sendPWM();
void sendData(char num);
void sendGraph(char id, unsigned short val);
void comData();
void cleanBuffer();




unsigned short TOUT = 0, CheckSum;
unsigned short T_Byte1, T_Byte2, RH_Byte1, RH_Byte2;
char TEMP[3] = " ";
char buffer[ 4 ], REC, index = 0;
char pwmBuffer[4] = "000";
char i, PWMVALUE = 0x7F;
volatile unsigned char uartDataReady = 0;
unsigned int sensorTick = 0;



void interrupt(){
 if(RCIF_bit) {
 REC = RCREG;
 RCIF_bit = 0;

 if(FERR_bit || OERR_bit) {
 CREN_bit = 0;
 CREN_bit = 1;
 return;
 }


 if((REC >= '0' && REC <= '9')) {
 if(index <  4  - 1) {
 buffer[index++] = REC;
 buffer[index] = '\0';
 }
 }

 if(index == 3){
 if(strcmp(buffer, "300") == 0){
 RB5_bit = 1;
 CCP1CON = 0x0C;
 uartDataReady = 1;
 }
 else if(strcmp(buffer, "400") == 0){
 RB5_bit = 0;
 CCP1CON = 0x00;
 RB3_bit = 0;
 uartDataReady = 1;
 }

 else if(strcmp(buffer, "500") == 0){
 RB5_bit = 0;
 CCP1CON = 0x00;
 RB3_bit = 0;
 uartDataReady = 1;
 }

 else{
 strcpy(pwmBuffer, buffer);
 uartDataReady = 1;
 }
 index = 0;
 }
 }

 if(PIR1.TMR1IF){
 PIR1.TMR1IF = 0;
 TOUT = 1;
 T1CON.TMR1ON = 0;
 sensorData = 1;
 }
}


void main() {

 CMCON = 0x07;
 OPTION_REG = 0x86;
 GIE_bit = 0x01;
 PEIE_bit = 0x01;

 PIE1.TMR1IE = 0x01;

 PR2 = 0xFF;
 T2CON = 0x06;
 CCP1CON = 0x0C;
 CCPR1L = 0x00;

 delay_ms(1000);
 RCIF_bit = 0x00;
 RCIE_bit = 0x01;
 SPBRG = 0x19;
 TXEN_bit = 0x01;
 BRGH_bit = 0x01;
 SYNC_bit = 0x00;
 SPEN_bit = 0x01;
 CREN_bit = 0x01;

 TRISA = 0x01;
 PORTA = 0x01;
 TRISB = 0x02;
 PORTB = 0x02;


 while(1){

 if(uartDataReady){
 PWMVALUE = atoi(pwmBuffer);
 uartDataReady = 0;
 PWM();
 }
 sensorTick++;
 if(sensorTick > 1200) {
 StartSignal();
 sensor();
 sensorTick = 0;
 }
 Delay_ms(1);
 }
}



void PWM() {
 CCPR1L = PWMVALUE;
 TEMP[0]= ((int)(PWMVALUE/2.53)/100%10) + 48;
 TEMP[1]= ((int)(PWMVALUE/2.53)/10%10) + 48;
 TEMP[2]= ((int)(PWMVALUE/2.53)%10) + 48;
 sendPWM();

}


 void StartSignal(){
 DataDir = 0;
 sensorData = 0;
 Delay_ms(18);
 sensorData = 1;

 T1CON = 0x00;
 PIR1.TMR1IF = 0x00;
 TMR1L = 0x00;
 TMR1H = 0xFF;
 T1CON.TMR1ON = 1;

 if(TMR1L == 22){
 DataDir = 1;
 T1CON.TMR1ON = 0;
 TMR1L = 0x00;
 TMR1H = 0xFF;
 }
}


unsigned short CheckResponse(){
 TOUT = 0;
 TMR1L = 0x00;
 TMR1H = 0xFF;
 T1CON.TMR1ON = 1;

 while(!sensorData && !TOUT);
 if (TOUT)
 return 0;

 else {
 TMR1L = 0x00;
 TMR1H = 0xFF;
 while(sensorData && !TOUT);
 if (TOUT)
 return 0;

 else {
 T1CON.TMR1ON = 0;
 return 1;
 }
 }
}


unsigned short ReadByte(){
 unsigned short num = 0, i;
 DataDir = 1;

 for (i=0; i<8; i++){
 while(!sensorData);
 TMR1L = 0x00;
 TMR1H = 0xFF;
 T1CON.TMR1ON = 1;
 while(sensorData);
 T1CON.TMR1ON = 0;

 if(TMR1L > 40)
 num |= 1<<(7-i);
 }
 return num;
}


void sensor(){
 unsigned short check;
 static char dataSend = 0x00;
 check = CheckResponse();

 if (!check){

 TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
 TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
 TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
 TXREG = '1'; cleanBuffer();
 TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();

 RB5_bit = 0;
 CCP1CON = 0x00;
 RB3_bit = 0;
 }

 else{
 RH_Byte1 = ReadByte();
 RH_Byte2 = ReadByte();
 T_Byte1 = ReadByte();
 T_Byte2 = ReadByte();
 CheckSum = ReadByte();

 if (CheckSum == ((RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF)){

 TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
 TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
 TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
 TXREG = '0'; cleanBuffer();
 TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();


 if(T_Byte1 > 2) T_Byte1 -=  2 ;
 else T_Byte1 = 0;

 if(RH_Byte1 > 3) RH_Byte1 -=  7 ;
 else RH_Byte1 = 0;


 TEMP[0] = RH_Byte1/10 + 48;
 TEMP[1] = RH_Byte1%10 + 48;
 TEMP[2] = RH_Byte2/10 + 48;
 sendData('1');
 sendGraph('1', RH_Byte1);



 TEMP[0] = T_Byte1/10 + 48;
 TEMP[1] = T_Byte1%10 + 48;
 TEMP[2] = T_Byte2/10 + 48;
 sendData('0');
 sendGraph('0', T_Byte1);

 }

 else{

 TXREG = 'e'; cleanBuffer(); TXREG = 'r'; cleanBuffer();
 TXREG = '0'; cleanBuffer(); TXREG = '.'; cleanBuffer(); TXREG = 'v'; cleanBuffer();
 TXREG = 'a'; cleanBuffer(); TXREG = 'l'; cleanBuffer(); TXREG = '='; cleanBuffer();
 TXREG = '0'; cleanBuffer();
 TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer(); TXREG = 0xFF; cleanBuffer();
 }

 }

}


 void sendPWM(){
 TXREG = 'n';
 cleanBuffer();
 TXREG = '0';
 cleanBuffer();
 TXREG = '.';
 cleanBuffer();
 TXREG = 'v';
 cleanBuffer();
 TXREG = 'a';
 cleanBuffer();
 TXREG = 'l';
 cleanBuffer();
 TXREG = '=';
 cleanBuffer();
 comData();
}


 void sendData(char num)
{
 TXREG = 'x';
 cleanBuffer();
 TXREG = num;
 cleanBuffer();
 TXREG = '.';
 cleanBuffer();
 TXREG = 'v';
 cleanBuffer();
 TXREG = 'a';
 cleanBuffer();
 TXREG = 'l';
 cleanBuffer();
 TXREG = '=';
 cleanBuffer();
 comData();
}


 void sendGraph(char id, unsigned short val){
 TEMP[0] = (val / 100) + 48;
 TEMP[1] = ((val / 10) % 10) + 48;
 TEMP[2] = (val % 10) + 48;


 TXREG = 'g'; cleanBuffer();
 TXREG = 'r'; cleanBuffer();


 if(id == '0') { TXREG = '0';
 } else { TXREG = '1'; }
 cleanBuffer();


 TXREG = '.'; cleanBuffer();
 TXREG = 'v'; cleanBuffer();
 TXREG = 'a'; cleanBuffer();
 TXREG = 'l'; cleanBuffer();
 TXREG = '='; cleanBuffer();


 TXREG = TEMP[0]; cleanBuffer();
 TXREG = TEMP[1]; cleanBuffer();
 TXREG = TEMP[2]; cleanBuffer();


 TXREG = 0xFF; cleanBuffer();
 TXREG = 0xFF; cleanBuffer();
 TXREG = 0xFF; cleanBuffer();
}


void comData()
{
 TXREG = TEMP[0];
 cleanBuffer();
 TXREG = TEMP[1];
 cleanBuffer();
 TXREG = TEMP[2];
 cleanBuffer();
 TXREG = 0xFF;
 cleanBuffer();
 TXREG = 0xFF;
 cleanBuffer();
 TXREG = 0xFF;
 cleanBuffer();
}


void cleanBuffer()
{
 while(!TRMT_bit);
}
