#line 1 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/zGeral/1Concluidos/Eng. Josias/Display Nextion/HMI Common Files/Application/HMI_PIC16F628A/main.c"
#line 21 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/zGeral/1Concluidos/Eng. Josias/Display Nextion/HMI Common Files/Application/HMI_PIC16F628A/main.c"
sbit EMG at RB0_bit;
sbit PWM_OUT at RB3_bit;
sbit POWER at RB5_bit;
sbit SENSOR_DATA at RA0_bit;
sbit DATA_DIR at TRISA0_bit;









void PWM();

void StartSignal();
void sensor();
unsigned short CheckResponse();
unsigned short ReadByte();

void sendPWM();
void sendData(char val);
void sendGraph(char id);
void errorState(char id, char val);

void hmi_nameParameter();
void commonData();
void hmi_endCommand();
void cleanBuffer();




unsigned short TOUT = 0, CheckSum;
unsigned short T_Byte1, T_Byte2, RH_Byte1, RH_Byte2;
unsigned int sensorTick = 0;
char TEMP[3] = " ", buffer[ 4 ], REC, index = 0;
char pwmBuffer[4] = "000";
char i, PWM_VALUE = 0;
volatile unsigned char uartDataReady = 0;
volatile char softwareEmgState = 0, hardwareEmgState = 0, sensorError = 0;



void interrupt(){
 if(INTF_bit){

 hardwareEmgState = 1;
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;
 INTF_bit = 0;
 }

 if(!hardwareEmgState){
 if(RCIF_bit){

 if(OERR_bit){
 CREN_bit = 0;
 CREN_bit = 1;
 REC = RCREG;
 return;
 }

 if(FERR_bit){
 REC = RCREG;
 return;
 }

 REC = RCREG;

 if((REC >= '0' && REC <= '9')){
 if(index <  4  - 1){
 buffer[index++] = REC;
 buffer[index] = '\0';
 }
 }

 if(index == 3){
 if(strcmp(buffer, "300") == 0){
 CCP1CON = 0x0C;
 POWER = 1;
 }

 else if(strcmp(buffer, "400") == 0){
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;
 }

 else if(strcmp(buffer, "500") == 0){
 softwareEmgState = 1;
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;
 }

 else if(strcmp(buffer, "600") == 0){
 if(sensorError){
 sensorError = 0;
 }
 else asm goto 0x0000;
 }

 else strcpy(pwmBuffer, buffer);
 uartDataReady = 1;
 index = 0;
 }
 }

 if(PIR1.TMR1IF){

 PIR1.TMR1IF = 0;
 TOUT = 1;
 T1CON.TMR1ON = 0;
 SENSOR_DATA = 1;
 }
 }
}



void main(){
 CMCON = 0x07;
 OPTION_REG = 0x86;
 INTE_bit = 0x01;
 GIE_bit = 0x01;
 PEIE_bit = 0x01;

 PIE1.TMR1IE = 0x01;

 PR2 = 0xFF;
 T2CON = 0x06;
 CCP1CON = 0x0C;
 CCPR1L = 0x00;

 delay_ms(1000);
 RCIF_bit = 0x00;
 RCIE_bit = 0x01;

 SPBRG = 0x19;
 TXEN_bit = 0x01;
 BRGH_bit = 0x01;
 SYNC_bit = 0x00;
 SPEN_bit = 0x01;
 CREN_bit = 0x01;

 TRISA = 0x01;
 PORTA = 0x01;
 TRISB = 0x03;
 PORTB = 0x03;

 if (EMG == 0) hardwareEmgState = 1;

 else{
 TXREG = 'r'; cleanBuffer();
 TXREG = 'e'; cleanBuffer();
 TXREG = 's'; cleanBuffer();
 hmi_nameParameter();
 TXREG = '1'; cleanBuffer();
 hmi_endCommand();
 }

 while(1){
 if(!softwareEmgState && !hardwareEmgState){
 if(uartDataReady){
 PWM_VALUE = atoi(pwmBuffer);
 uartDataReady = 0;
 PWM();
 }
 sensorTick++;
 if(sensorTick >  1200 ){
 StartSignal();
 sensor();
 sensorTick = 0;
 }
 }

 else{
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;

 while(1){
 errorState('1','1');
 delay_ms(500);
 }
 }
 Delay_ms(1);
 }
}




void PWM(){
 CCPR1L = PWM_VALUE;
 TEMP[0]= ((int)(PWM_VALUE/2.53)/100%10) + 48;
 TEMP[1]= ((int)(PWM_VALUE/2.53)/10%10) + 48;
 TEMP[2]= ((int)(PWM_VALUE/2.53)%10) + 48;
 sendPWM();
}




void StartSignal(){
 DATA_DIR = 0;

 SENSOR_DATA = 0;
 Delay_ms(18);
 SENSOR_DATA = 1;

 T1CON = 0x00;
 PIR1.TMR1IF = 0x00;
 TMR1L = 0x00;
 TMR1H = 0xFF;
 T1CON.TMR1ON = 1;

 if(TMR1L == 22){
 DATA_DIR = 1;
 SENSOR_DATA = 0;
 T1CON.TMR1ON = 0;
 TMR1L = 0x00;
 TMR1H = 0xFF;
 }
}




void sensor(){
 unsigned short check;
 static char dataSend = 0x00;
 check = CheckResponse();

 if (!check){
 errorState('0','1');
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;
 sensorError = 1;
 }

 else{

 RH_Byte1 = ReadByte();
 RH_Byte2 = ReadByte();
 T_Byte1 = ReadByte();
 T_Byte2 = ReadByte();
 CheckSum = ReadByte();


 if ((CheckSum == (RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF) && !sensorError){
 errorState('0','0');


 if(T_Byte1 >  2 ) T_Byte1 -=  2 ;
 else T_Byte1 = 0;

 if(RH_Byte1 >  7 ) RH_Byte1 -=  7 ;
 else RH_Byte1 = 0;


 TEMP[0] = RH_Byte1/100 + 48;
 TEMP[1] = ((RH_Byte1/10)%10) + 48;
 TEMP[2] = RH_Byte1%10 + 48;
 sendData('1');
 sendGraph('1');


 TEMP[0] = T_Byte1/100 + 48;
 TEMP[1] = ((T_Byte1/10)%10) + 48;
 TEMP[2] = T_Byte1%10 + 48;
 sendData('0');
 sendGraph('0');

 }

 else{

 errorState('0', '1');
 CCP1CON = 0x00;
 PWM_OUT = 0;
 POWER = 0;
 sensorError = 1;
 }
 }
}




unsigned short CheckResponse(){
 TOUT = 0;
 T1CON.TMR1ON = 1;

 while(!SENSOR_DATA && !TOUT);
 if(TOUT)
 return 0;

 else{
 TMR1L = 0x00;
 TMR1H = 0xFF;

 while(SENSOR_DATA && !TOUT);
 if(TOUT)
 return 0;

 else{
 T1CON.TMR1ON = 0;
 return 1;
 }
 }
}




unsigned short ReadByte(){
 unsigned short num = 0, i;
 DATA_DIR = 1;

 for (i=0; i<8; i++){
 while(!SENSOR_DATA);

 TMR1L = 0x00;
 TMR1H = 0xFF;
 T1CON.TMR1ON = 1;
 while(SENSOR_DATA);
 T1CON.TMR1ON = 0;

 if(TMR1L > 40)
 num |= 1<<(7-i);
 }
 return num;
}





 void sendPWM(){
 TXREG = 'n'; cleanBuffer();
 TXREG = '0'; cleanBuffer();
 hmi_nameParameter();
 commonData();
}





 void sendData(char val){
 TXREG = 'x'; cleanBuffer();
 TXREG = val; cleanBuffer();
 hmi_nameParameter();
 commonData();
}





 void sendGraph(char id){

 TXREG = 'g'; cleanBuffer();
 TXREG = 'r'; cleanBuffer();


 if(id == '0'){
 TXREG = '0';
 }
 else{
 TXREG = '1';
 }
 cleanBuffer();
 hmi_nameParameter();
 commonData();
 hmi_endCommand();
}





void errorState(char id, char val){
 TXREG = 'e'; cleanBuffer();
 TXREG = 'r'; cleanBuffer();
 TXREG = id; cleanBuffer();
 hmi_nameParameter();
 TXREG = val; cleanBuffer();
 hmi_endCommand();
}




void hmi_nameParameter(){
 TXREG = '.'; cleanBuffer();
 TXREG = 'v'; cleanBuffer();
 TXREG = 'a'; cleanBuffer();
 TXREG = 'l'; cleanBuffer();
 TXREG = '='; cleanBuffer();
}




void commonData(){
 TXREG = TEMP[0]; cleanBuffer();
 TXREG = TEMP[1]; cleanBuffer();
 TXREG = TEMP[2]; cleanBuffer();
 hmi_endCommand();
}




void hmi_endCommand(){
 TXREG = 0xFF; cleanBuffer();
 TXREG = 0xFF; cleanBuffer();
 TXREG = 0xFF; cleanBuffer();
}




void cleanBuffer(){
 while(!TRMT_bit);
}
